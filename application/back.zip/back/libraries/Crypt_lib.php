<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH . 'third_party/vendor/autoload.php';

class Crypt_lib
{
    function get_payment_qr($coin,$my_address,$parameters,$amount,$callback_url){
       
        //$callback_url = 'https://example.com';
        $cryptapi_params = [
            'pending' => 1
        ];

        $ca = new CryptAPI\CryptAPI($coin, $my_address, $callback_url, $parameters, $cryptapi_params);
        //$payment_address = $ca->get_address();
        $qrcode = $ca->get_qrcode($amount, 128);
        return $qrcode;
    }

    function callback_data($parm){
        $payment_data = CryptAPI\CryptAPI::process_callback($parm);
        return $payment_data;
    }
}