<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Front extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->model('common_model');
	}


	public function index()
	{
		$data['title'] = "Welcome to FXMINER";
		$this->load->view('front/home', $data);
	}

	function expert_advisors()
	{
		$data['title'] = "FXMINER | Expert Advisors";
		$this->load->view('front/expert_advisors', $data);
	}

	function contact_us()
	{
		$data['title'] = "FXMINER | Contact Us";
		$this->load->view('front/contact', $data);
	}


	function submit_enquiry()
	{
		if (isset($_POST)) {
			$this->form_validation->set_rules('name', 'Name', 'required|trim|max_length[45]|alpha_numeric_spaces');
			$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|max_length[100]');
			$this->form_validation->set_rules('mobile', 'Mobile Number', 'required|trim|exact_length[10]');
			$this->form_validation->set_rules('subject', 'Subject', 'trim|max_length[45]');
			$this->form_validation->set_rules('message', 'Message', 'trim|max_length[250]');
			$this->form_validation->set_rules('captcha', 'Captcha', 'required|trim|exact_length[6]|callback__check_captcha');

			if ($this->form_validation->run() == FALSE) {
				echo json_encode(array("success" => false, "error" => validation_errors()));
			} else {
				$this->db->trans_start();
				$name = $_POST['name'];
				$email = $_POST['email'];
				$mobile = $_POST['mobile'];
				$subject = $_POST['subject'];
				$message = $_POST['message'];




				//create array of all post values 
				$data = array(
					'contact_name' => $name,
					'contact_mobile' => $mobile,
					'contact_email' => $email,
					'contact_subject' => $subject,
					'contact_message' => $message,
					'enquiry_status' => 0,
					'submission_date_time' => date('Y-m-d H:i:s'),

				);
				$table = 'contact_enquiry';
				$result = $this->_insert($data, $table);		//Insert data in database table through common insert function
				$this->db->trans_complete();

				if ($result != "") {
					echo json_encode(array("success" => true));
				} else {
					echo json_encode(array("success" => false, "error" => "Something went wrong"));
				}
			}
		}
	}


	function captcha_code()
	{
		if ($_POST['action'] == 'load-image') {
			$this->load->helper('captcha_helper');
			// numeric random number for captcha
			$random_number = substr(number_format(time() * rand(), 0, '', ''), 0, 6);
			// setting up captcha config
			$target_path = './uploads/captcha/';
			if (!is_dir($target_path)) { // creating the target path directory if not exist
				mkdir($target_path, 0777, TRUE);
			}
			$vals = array(
				'word' => $random_number,
				'img_path' => $target_path,
				'img_url' => base_url() . 'uploads/captcha/',
				'img_width' => 150,
				'img_height' => 35,
				'expiration' => 7200
			);

			$data['captcha'] = create_captcha($vals);
			$this->session->set_userdata('captchaWord', $data['captcha']['word']);
			$filename = $data['captcha']['filename'];
			echo json_encode(array("success" => $filename));
		}
	}



	function _check_captcha($str)
	{
		$word = $this->session->userdata('captchaWord');
		if (strcmp(strtoupper($str), strtoupper($word)) == 0) {
			return true;
		} else {
			$this->form_validation->set_message('_check_captcha', 'Invalid Captcha');
			return false;
		}
	}


	/* Common function for data insert in database table */
	function _insert($data, $table)
	{
		$last_id = $this->common_model->insert($data, $table);    //Insert data in database table through model 
		if ($last_id) {
			return $last_id;
		} else {
			return false;
		}
	}
	
	function symbol_chart()
	{
		$data['page_title'] = 'Live Chart';
		$this->load->view('admin/live_chart', $data);
	}
}//End Class
