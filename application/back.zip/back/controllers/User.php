<?php
class User extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('common_model');
        $this->load->model('user/user_model');
        is_logged_in();
    }

    function home()
    {
        $user_id = get_user_id();
        $user_details = $this->user_model->getUserDetails($user_id);
        $data['user_details'] = $user_details;
        $this->load->view('user/home',$data);
    }

    function create_account()
    {
        $this->load->view('user/create_account');
    }

    function start_trading()
    {
        $pWhr = "status = 1";
        $payment_method = $this->common_model->getRecordData('payment_method', $pWhr);
        $data['payment_method'] = $payment_method;
        $this->load->view('user/start_trading', $data);
    }

    function get_qrcode()
    {

        $formMsg = array('status' => 'error', 'msg' => 'Invalid Data.');
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $method = $_POST['method_id'];

            if ($method == '7sb0HhFOpRWRAHfOKxM1QA_E0L0S__E0L0S_' || $method == 'f4S6C_S0L0H_amUTH36Z2OjmVhZQ_E0L0S__E0L0S_') {
                if ($method == 'f4S6C_S0L0H_amUTH36Z2OjmVhZQ_E0L0S__E0L0S_') {
                    $coin = 'trc20_usdt';
                    $my_address = 'THwvpLa6bMRTLvxbB2cFFQzUcoVNoXJCTJ';
                } else {
                    $coin = 'bep20_usdt';
                    $my_address = '0x64377b35ab5d687Dec7E11fE4016f314703B1B0B';
                }
                $user_id = get_user_id();
                $transaction_no = get_transaction_no();
                $currency = $coin;
                $amount = 100;
                $parameters = ['transaction_no' => $transaction_no];
                $this->load->library('Crypt_lib');
                $trans_no_enc = base64e($transaction_no);
                $callback_url = site_url('user/user_rec?payment_id=' . $trans_no_enc);
                $qrcode = $this->crypt_lib->get_payment_qr($coin, $my_address, $parameters, $amount, $callback_url);

                if (isset($qrcode->status)) {
                    $status = $qrcode->status;
                    if ($status == 'success') {
                        $qr = $qrcode->qr_code;
                        $user_name = get_user_name();
                        $payment_method_id = base64d($method);
                        $description = 'Payment request for' . $amount . ' created by ' . $user_name;
                        $uData = array(
                            'user_id' => $user_id,
                            'order_id' => $transaction_no,
                            'transaction_no' => $transaction_no,
                            'payment_method_id' => $payment_method_id,
                            'currency' => $currency,
                            'amount' => $amount,
                            'status_id' => 1,
                            'description' => $description,
                            'qr' => $qr
                        );
                        $rData = $this->common_model->insert($uData, 'payments');
                        if (is_numeric($rData)) {
                            $html = '<img src="data:image/png;base64,' . $qrcode->qr_code . '"/><button type="submit" class="btn btn-outline-primary btn-wave"></button>';
                            $formMsg = array('status' => 'success', 'msg' => $html);
                        }
                    }
                }
            }
        }
        echo json_encode($formMsg);
    }

    function user_rec()
    {
        if (isset($_GET['payment_id']) && $_GET['payment_id'] != '') {
            $payment_id = base64d($_GET['payment_id']);
            if (is_numeric($payment_id)) {
                $cWhr = "transaction_no = " . $payment_id;
                $recByno = $this->common_model->getRecordData('payments', $cWhr);
                if (!empty($recByno)) {
                    $payment_id = $recByno[0]['payment_id'];
                    $this->load->library('Crypt_lib');
                    $payment_callback_data = $this->crypt_lib->get_payment_qr($_GET);
                    date_default_timezone_set('Asia/Kolkata');
                    $response_received_at = date('Y-m-d H:i:s');
                    $udata = array('response' => $payment_callback_data, 'response_received_at' => $response_received_at);
                    $rData = $this->common_model->update($payment_id, $udata, 'payment_id', 'payments');
                }
            }
        }
    }

    function save_server_details()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $user_id = get_user_id();
            $server_name = $this->input->post('server_name');
            $trading_id = $this->input->post('trading_id');
            $trading_password = base64e($this->input->post('trading_password'));
            $email_id = $this->input->post('email_id');
            $udata = array(
                'user_id' => $user_id,
                'server' => $server_name,
                'td_id' => $trading_id,
                'password' => $trading_password,
                'email_id' => $email_id,
                'server' => $server_name,
            );
            $rData = $this->common_model->insert($udata, 'user_td_account');
        }
        redirect('user/payment_successful');
    }

    function payment_successful()
    {
        $this->load->view('user/payment_successful');
    }

    

    function test()
    {
        $method = 'Et7yNCJa4q';
        if ($method == 'Et7yNCJa4q') {
            $coin = 'trc20_usdt';
            $my_address = 'THwvpLa6bMRTLvxbB2cFFQzUcoVNoXJCTJ';
        } else {
            $coin = 'bep20_usdt';
            $my_address = '0x64377b35ab5d687Dec7E11fE4016f314703B1B0B';
        }
        $user_id = get_user_id();
        $transaction_no = get_transaction_no();
        $currency = $coin;
        $amount = 100;
        $status_id = 1;
        $response = '';
        $description = '';
        $response = '';
        $parameters = ['transaction_no' => $transaction_no];
        $this->load->library('Crypt_lib');
        $q = $this->crypt_lib->get_payment_qr($coin, $my_address, $parameters, $amount);
        print_r($q);
    }

    public function send()
    {
        $this->load->library('Email_lib');

        $result = $this->email_lib->send_email(
            'sarbjotseemar6@gmail.com',
            'Test Email',
            '<h2>This is a Gmail SMTP test from CI3 library</h2>'
        );

        if ($result === true) {
            echo "Email sent!";
        } else {
            echo $result; // show debug output
        }
    }

    function ss()
    {
        $ps = 'glrx ouse fqqh jfuh ';
    }

    function refer_friend()
    {
        $user_id = get_user_id();
        $whr = "user_id = " . $user_id;
        $refData = $this->common_model->getRecordData('itroducing_alpha', $whr);
        $data['refData'] = $refData;
        $this->load->view('user/refer_friend', $data);
    }

    function apply_refferal()
    {
        $user_id = get_user_id();
        $whr = "user_id = " . $user_id;
        $rData = 'error';
        $getById = $this->common_model->getRecordData('itroducing_alpha', $whr);
        if (empty($getById)) {
            $user_name = get_user_name();
            $date = date('Y-m-d');
            $data = array(
                'user_id' => $user_id,
                'user_name' => $user_name,
                'status' => 0,
                'date' => $date
            );
            $rData = $this->common_model->insert($data, 'itroducing_alpha');
        }
        if (is_numeric($rData)) {
            redirect('user/thanksforapplying');
        }else{
            redirect('user/refer_friend');
        }
        
    }

    function thanksforapplying(){
        $this->load->view('user/thanks');
    }

    function user_profile(){
        $user_id = get_user_id();
        $recById = $this->user_model->getUserDetails($user_id);
        $data['recById'] = $recById;
        $this->load->view('user/user_profile',$data);
    }

    function profile_settings(){
        $user_id = get_user_id();
        $whr = "user_id = ".$user_id;
        $recById = $this->common_model->getRecordData('users',$whr);
        $data['recById'] = $recById;
        $data['countriesRec'] = $this->common_model->getRecordData('countries');
        $data['gendersRec'] = $this->common_model->getRecordData('genders');
        $this->load->view('user/profile_settings',$data);
    }

    function save_profile_settings(){
        $formSubmit = array('status' => 'error', 'url' => '', 'msg' => 'Something Went Wrong.');
        $user_id = get_user_id();
        $whr = "user_id = ".$user_id;
        $recById = $this->common_model->getRecordData('users',$whr);
        if(empty($recById)){
            echo json_encode($formSubmit);
            exit;
        }
        $db_user_name = $recById[0]['username'];
        $username = $this->input->post('username');
        $is_unique = '|is_unique[users.username]';
        if($db_user_name == $username){
            $is_unique = '';
        }
        $this->form_validation->set_rules('username', 'Username', 'trim|required|max_length[30]'.$is_unique);
        $this->form_validation->set_rules('full_name', 'name', 'trim|required|alpha_numeric_spaces|max_length[30]');
        $this->form_validation->set_rules('gender', 'Gender', 'trim');
        $this->form_validation->set_rules('dob', 'DOB', 'trim');
        $this->form_validation->set_rules('mobile', 'Mobile', 'trim|numeric|min_length[10]|max_length[15]');
        $this->form_validation->set_rules('country', 'Country', 'trim');
        $this->form_validation->set_rules('address', 'Address', 'trim');
        if ($this->form_validation->run() == false) {
            $errors = validation_errors();
            $errors = str_replace("<p>", "<li>", $errors);
            $errors = str_replace("</p>", "</li>", $errors);
            $errors = str_replace("The", "", $errors);
            $errors = '<ul>' . $errors . '</ul>';
            $formSubmit['msg'] = $errors;
            echo json_encode($formSubmit);
        } else {
            $username = $this->input->post('username');
            $name = $this->input->post('full_name');
            $gender = $this->input->post('gender');
            $gender_id = '';
            if($gender !=''){
                $gender_id = (int)base64d($gender);
            }
            $country = $this->input->post('country');
            $country_id = '';
            if($country != ''){
                $country_id = (int)base64d($country);
            }
            $date = $this->input->post('dob');
            $mobile = $this->input->post('mobile');
            $address = $this->input->post('address');

            $uData = array(
                'username'=>$username,
                'full_name'=>$name,
                'gender_id'=>$gender_id,
                'country_id'=>$country_id,
                'dob'=>$date,
                'mobile'=>$mobile,
                'address'=>$address

            );
            $rData = $this->common_model->update($user_id,$uData,'user_id','users');
            if(is_numeric($rData)){
                $formSubmit['status'] = 'success';
                $formSubmit['url'] = site_url('user/user_profile');
                $formSubmit['msg'] = 'Your Profile Settings Changed Successfully.';
            }
            echo json_encode($formSubmit);
        }
    }
}
