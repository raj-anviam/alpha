<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->model('common_model');
		is_logged_in();
	}


	public function index()
	{
		$data['page_title'] = 'Dashboard';
		$this->load->view('admin/dashboard', $data);
	}

	public function heat_map()
	{
		//$this->load->library('Socket_lib');
		//$socketData = $this->socket_lib->run_connection();
		//echo '<pre>';
		// print_r($socketData);
		// exit;
		$data['page_title'] = 'Forex Heat Map';
		$this->load->view('admin/heat_map', $data);
	}

	public function rates()
	{
		$data['page_title'] = 'Forex Cross Rates';
		$this->load->view('admin/rates', $data);
	}

	public function calculator()
	{
		$data['page_title'] = 'Lot Size Calculator';
		$this->load->view('admin/calculator', $data);
	}

	public function chart()
	{
		$data['page_title'] = 'Live Chart';
		$this->load->view('admin/chart', $data);
	}

	public function rating()
	{
		$all_period = $this->common_model->getRecordData('forex_period');
		$all_symbol = $this->common_model->getRecordData('forex_symbol');
		$filter_indicator_symbol = array_filter($all_symbol, function ($value) {
			return ($value['show_in_indicator'] == 1);
		});
		$indicator_data = array();
		foreach ($filter_indicator_symbol as $val) {
			$symbol = $val['symbol'];
			$indicator_data[$symbol] = get_indecator_data($symbol);
		}
		$data['indicator_data'] = $indicator_data;
		$data['all_symbol'] = $all_symbol;
		$data['all_period'] = $all_period;
		$data['page_title'] = 'Technical Rating';
		$this->load->view('admin/rating', $data);
	}
	public function rating_e()
	{
		$all_period = $this->common_model->getRecordData('forex_period');
		$all_symbol = $this->common_model->getRecordData('forex_symbol');
		$filter_indicator_symbol = array_filter($all_symbol, function ($value) {
			return ($value['show_in_indicator'] == 1);
		});
		$indicator_data = array();
		foreach ($filter_indicator_symbol as $val) {
			$symbol = $val['symbol'];
			$indicator_data[$symbol] = get_indecator_data($symbol);
			echo '<pre>'; print_r($indicator_data[$symbol]); exit;
		}
		echo '<pre>'; print_r($indicator_data); exit;
		$data['indicator_data'] = $indicator_data;
		$data['all_symbol'] = $all_symbol;
		$data['all_period'] = $all_period;
		$data['page_title'] = 'Technical Rating';
		$this->load->view('admin/rating', $data);
	}

	function get_symbol_analysis()
	{
		$symbol = $period = '';
		if (isset($_POST['symbol'])) {
			$symbol = $_POST['symbol'];
		}
		if (isset($_POST['period'])) {
			$period = $_POST['period'];
		}
		if ($symbol != '' && $period != '') {
			$symbol_analysis = $pivot_point = $summary = '';
			$indicator_data = get_indecator_data($symbol, $period);

			if (!empty($indicator_data)) {
				$symbol_analysis = '<table class="table">';
				if (isset($indicator_data['count'])) {
					$symbol_analysis .= '<tr>';
					foreach ($indicator_data['count'] as $key => $val) {
						$textclass = 'btn-primary';
						if (strpos(strtolower($key), 'sell') !== false) {
							$textclass = 'btn-danger';
						} elseif (strpos(strtolower($key), 'buy') !== false) {
							$textclass = 'btn-success';
						}
						$symbol_analysis .= '<td><button type="button" class="btn btn-sm fw-bold ' . $textclass . '">' . str_replace('_', ' ', $key) . ' ' . $val . '</button></td>';
					}
					$symbol_analysis .= '</tr>';
				}
				if (isset($indicator_data['indicators'])) {
					foreach ($indicator_data['indicators'] as $key => $val) {
						if (is_array($val)) {
							$symbol_analysis .= '<tr>';
							$symbol_analysis .= '<th>' . str_replace('_', ' ', $key) . '</th>';
							foreach ($val as $detail) {
								$tdTextclass = 'text-warning';
								if (strpos(strtolower($detail), 'sell') !== false) {
									$tdTextclass = 'text-danger';
								} elseif (strpos(strtolower($detail), 'buy') !== false) {
									$tdTextclass = 'text-success';
								} elseif (strpos(strtolower($detail), 'sold') !== false) {
									$tdTextclass = 'text-info';
								}
								$symbol_analysis .= '<td class="' . $tdTextclass . ' text-center">' . $detail . '</td>';
							}
							$symbol_analysis .= '</tr>';
						}
					}
				}
				$symbol_analysis .= '</table>';
				if (isset($indicator_data['overall']['summary'])) {
					$summary .= '<h4>' . $indicator_data['overall']['summary'] . '</h4>';
				}
				/*
				if (isset($indicator_data['overall']['change_at'])) {
					$summary .= '<p class="text-info"> Change at ' . $indicator_data['overall']['change_at'] . '</p>';
				}*/
				if (isset($indicator_data['overall']['msg'])) {
					$msg = ucwords($indicator_data['overall']['msg']);
					$summary .= '<p class="text-warning">' . $msg . '</p>';
				}
			}
			$pivot_point_data = get_pivot_point($symbol, $period);
			if (!empty($pivot_point_data)) {
				if (isset($pivot_point_data['pivot_point']['classic'])) {
					$classic = $pivot_point_data['pivot_point']['classic'];
					$PP = (isset($classic['pp'])) ? 'PP : ' . $classic['pp'] : 'PP : 0';
					$S3 = (isset($classic['S3'])) ? 'S3 : ' . $classic['S3'] : 'S3 : 0';
					$S2 = (isset($classic['S2'])) ? 'S2 : ' . $classic['S2'] : 'S2 : 0';
					$S1 = (isset($classic['S1'])) ? 'S1 : ' . $classic['S1'] : 'S1 : 0';
					$R1 = (isset($classic['R1'])) ? 'R1 : ' . $classic['R1'] : 'R1 : 0';
					$R2 = (isset($classic['R2'])) ? 'R2 : ' . $classic['R2'] : 'R2 : 0';
					$R3 = (isset($classic['R3'])) ? 'R3 : ' . $classic['R3'] : 'R3 : 0';
					$pivot_point .= '<table class="table">';
					$pivot_point .= '<tr>';
					$pivot_point .= '<td colspan="3">' . $PP . '</td>';
					$pivot_point .= '</tr>';
					$pivot_point .= '<tr>';
					$pivot_point .= '<td>' . $S3 . '</td>';
					$pivot_point .= '<td>' . $S2 . '</td>';
					$pivot_point .= '<td>' . $S1 . '</td>';
					$pivot_point .= '</tr>';
					$pivot_point .= '<tr>';
					$pivot_point .= '<td>' . $R1 . '</td>';
					$pivot_point .= '<td>' . $R2 . '</td>';
					$pivot_point .= '<td>' . $R3 . '</td>';
					$pivot_point .= '</tr>';
					$pivot_point .= '</table>';
				}
			}
			echo json_encode(array('status' => 'success', 'symbol_analysis' => $symbol_analysis, 'pivot_point' => $pivot_point, 'summary' => $summary));
		} else {
			echo json_encode(array('status' => 'error', 'msg' => 'Invalid Data'));
		}
	}

	public function levels()
	{
		$data['page_title'] = 'Levels';
		$all_period = $this->common_model->getRecordData('forex_period');
		$all_symbol = $this->common_model->getRecordData('forex_symbol');
		$data['all_symbol'] = $all_symbol;
		$data['all_period'] = $all_period;
		$this->load->view('admin/levels', $data);
	}

	public function get_levels_data()
	{

		$symbol = $period = '';
		if (isset($_POST['symbol'])) {
			$symbol = $_POST['symbol'];
		}
		if (isset($_POST['period'])) {
			$period = $_POST['period'];
		}
		$summary = '';
		if ($symbol != '' && $period != '') {
			$pivot_point_data = get_pivot_point($symbol, $period);
			if (!empty($pivot_point_data)) {
				$pivot_point = '<table class="table"><thead><tr>';
				$pivot_point .= '<th>Levels</th><th>PP</th><th>S1</th><th>S2</th><th>S3</th><th>R1</th><th>R2</th><th>R3</th></tr></thead><tbody>';

				if (isset($pivot_point_data['pivot_point']['classic'])) {
					$classic = $pivot_point_data['pivot_point']['classic'];
					$PP = (isset($classic['pp'])) ? '' . $classic['pp'] : '0';
					$S3 = (isset($classic['S3'])) ? '' . $classic['S3'] : '0';
					$S2 = (isset($classic['S2'])) ? '' . $classic['S2'] : '0';
					$S1 = (isset($classic['S1'])) ? '' . $classic['S1'] : '0';
					$R1 = (isset($classic['R1'])) ? '' . $classic['R1'] : '0';
					$R2 = (isset($classic['R2'])) ? '' . $classic['R2'] : '0';
					$R3 = (isset($classic['R3'])) ? '' . $classic['R3'] : '0';
					$pivot_point .= '<tr><th>Classic</th>';
					$pivot_point .= '<td>' . $PP . '</td>';
					$pivot_point .= '<td>' . $S1 . '</td>';
					$pivot_point .= '<td>' . $S2 . '</td>';
					$pivot_point .= '<td>' . $S3 . '</td>';
					$pivot_point .= '<td>' . $R1 . '</td>';
					$pivot_point .= '<td>' . $R2 . '</td>';
					$pivot_point .= '<td>' . $R3 . '</td>';
					$pivot_point .= '</tr>';
				}
				if (isset($pivot_point_data['pivot_point']['fibonacci'])) {
					$fibonacci = $pivot_point_data['pivot_point']['fibonacci'];
					$PP = (isset($fibonacci['pp'])) ? '' . $fibonacci['pp'] : '0';
					$S3 = (isset($fibonacci['S3'])) ? '' . $fibonacci['S3'] : '0';
					$S2 = (isset($fibonacci['S2'])) ? '' . $fibonacci['S2'] : '0';
					$S1 = (isset($fibonacci['S1'])) ? '' . $fibonacci['S1'] : '0';
					$R1 = (isset($fibonacci['R1'])) ? '' . $fibonacci['R1'] : '0';
					$R2 = (isset($fibonacci['R2'])) ? '' . $fibonacci['R2'] : '0';
					$R3 = (isset($fibonacci['R3'])) ? '' . $fibonacci['R3'] : '0';
					$pivot_point .= '<tr><th>Fibonacci</th>';
					$pivot_point .= '<td>' . $PP . '</td>';
					$pivot_point .= '<td>' . $S1 . '</td>';
					$pivot_point .= '<td>' . $S2 . '</td>';
					$pivot_point .= '<td>' . $S3 . '</td>';
					$pivot_point .= '<td>' . $R1 . '</td>';
					$pivot_point .= '<td>' . $R2 . '</td>';
					$pivot_point .= '<td>' . $R3 . '</td>';
					$pivot_point .= '</tr>';
				}
				if (isset($pivot_point_data['pivot_point']['camarilla'])) {
					$camarilla = $pivot_point_data['pivot_point']['camarilla'];
					$PP = (isset($camarilla['pp'])) ? '' . $camarilla['pp'] : '0';
					$S3 = (isset($camarilla['S3'])) ? '' . $camarilla['S3'] : '0';
					$S2 = (isset($camarilla['S2'])) ? '' . $camarilla['S2'] : '0';
					$S1 = (isset($camarilla['S1'])) ? '' . $camarilla['S1'] : '0';
					$R1 = (isset($camarilla['R1'])) ? '' . $camarilla['R1'] : '0';
					$R2 = (isset($camarilla['R2'])) ? '' . $camarilla['R2'] : '0';
					$R3 = (isset($camarilla['R3'])) ? '' . $camarilla['R3'] : '0';
					$pivot_point .= '<tr><th>Camarilla</th>';
					$pivot_point .= '<td>' . $PP . '</td>';
					$pivot_point .= '<td>' . $S1 . '</td>';
					$pivot_point .= '<td>' . $S2 . '</td>';
					$pivot_point .= '<td>' . $S3 . '</td>';
					$pivot_point .= '<td>' . $R1 . '</td>';
					$pivot_point .= '<td>' . $R2 . '</td>';
					$pivot_point .= '<td>' . $R3 . '</td>';
					$pivot_point .= '</tr>';
				}
				if (isset($pivot_point_data['pivot_point']['woodie'])) {
					$woodie = $pivot_point_data['pivot_point']['woodie'];
					$PP = (isset($woodie['pp'])) ? '' . $woodie['pp'] : '0';
					$S3 = (isset($woodie['S3'])) ? '' . $woodie['S3'] : '0';
					$S2 = (isset($woodie['S2'])) ? '' . $woodie['S2'] : '0';
					$S1 = (isset($woodie['S1'])) ? '' . $woodie['S1'] : '0';
					$R1 = (isset($woodie['R1'])) ? '' . $woodie['R1'] : '0';
					$R2 = (isset($woodie['R2'])) ? '' . $woodie['R2'] : '0';
					$R3 = (isset($woodie['R3'])) ? '' . $woodie['R3'] : '0';
					$pivot_point .= '<tr><th>Woodie</th>';
					$pivot_point .= '<td>' . $PP . '</td>';
					$pivot_point .= '<td>' . $S1 . '</td>';
					$pivot_point .= '<td>' . $S2 . '</td>';
					$pivot_point .= '<td>' . $S3 . '</td>';
					$pivot_point .= '<td>' . $R1 . '</td>';
					$pivot_point .= '<td>' . $R2 . '</td>';
					$pivot_point .= '<td>' . $R3 . '</td>';
					$pivot_point .= '</tr>';
				}
				if (isset($pivot_point_data['pivot_point']['demark'])) {
					$demark = $pivot_point_data['pivot_point']['demark'];
					$PP = (isset($demark['pp'])) ? '' . $demark['pp'] : '0';
					$S3 = (isset($demark['S3'])) ? '' . $demark['S3'] : '0';
					$S2 = (isset($demark['S2'])) ? '' . $demark['S2'] : '0';
					$S1 = (isset($demark['S1'])) ? '' . $demark['S1'] : '0';
					$R1 = (isset($demark['R1'])) ? '' . $demark['R1'] : '0';
					$R2 = (isset($demark['R2'])) ? '' . $demark['R2'] : '0';
					$R3 = (isset($demark['R3'])) ? '' . $demark['R3'] : '0';
					$pivot_point .= '<tr><th>Demark</th>';
					$pivot_point .= '<td>' . $PP . '</td>';
					$pivot_point .= '<td>' . $S1 . '</td>';
					$pivot_point .= '<td>' . $S2 . '</td>';
					$pivot_point .= '<td>' . $S3 . '</td>';
					$pivot_point .= '<td>' . $R1 . '</td>';
					$pivot_point .= '<td>' . $R2 . '</td>';
					$pivot_point .= '<td>' . $R3 . '</td>';
					$pivot_point .= '</tr>';
				}
				$pivot_point .= '</tbody></table>';
				if (isset($pivot_point_data['overall']['summary'])) {
					$summary .= '<h4>' . $pivot_point_data['overall']['summary'] . '</h4>';
				}
				if (isset($pivot_point_data['overall']['change_at'])) {
					$summary .= '<p class="text-info"> Change at ' . $pivot_point_data['overall']['change_at'] . '</p>';
				}
				if (isset($pivot_point_data['overall']['msg'])) {
					$msg = ucwords($pivot_point_data['overall']['msg']);
					$summary .= '<p class="text-warning">' . $msg . '</p>';
				}
				echo json_encode(array('status' => 'success', 'pivot_point' => $pivot_point, 'summary' => $summary));
			} else {
				echo json_encode(array('status' => 'error', 'msg' => 'Invalid Data'));
			}
		} else {
			echo json_encode(array('status' => 'error', 'msg' => 'Invalid Data'));
		}
	}

	public function news()
	{
		$data['page_title'] = 'News';
		$this->load->view('admin/news', $data);
	}

	public function converter()
	{
		$data['page_title'] = 'Currency Converter';
		$this->load->view('admin/converter', $data);
	}

	public function calendar()
	{
		$data['page_title'] = 'Economic Calendar';
		$this->load->view('admin/calender', $data);
	}

	public function signals()
	{
		$data['page_title'] = 'Economic Calendar';
		$this->load->view('admin/signals', $data);
	}

	public function tutorial()
	{
		$data['page_title'] = 'Tutorial';
		$this->load->view('admin/tutorial', $data);
	}
	
	public function guide()
	{
		$data['page_title'] = 'Guide';
		$this->load->view('admin/guide', $data);
	}

	public function video_conference()
	{
		$user_id = get_user_id();
		$user_role_id = get_user_role();
		$user_name = get_user_name();
		$user_email = get_user_email();
		$title = $zoom_user_id = $description = $client_id = $meeting_id = $meeting_password = $signature = $zak_token = '';
		$duration = 0;
		//if(user_ip() == '38.137.27.93' || user_ip() == '92.98.246.230'){
		    
		 
			 if ($user_role_id == 1) {
				$zoom_user_id = '';
				$user_data = $this->common_model->getRecordData('user_registration', "user_id = '$user_id'", 'email,first_name,last_name,zoom_user_id');
				if (!empty($user_data)) {
					$zoom_user_id = $user_data[0]['zoom_user_id'];

					if ($zoom_user_id == '') {
						$email = $user_data[0]['email'];
						$first_name = $user_data[0]['first_name'];
						$last_name = $user_data[0]['last_name'];
						$display_name = $first_name;
						$zoom_user_data = create_zoom_user($email, $first_name, $last_name, $display_name);
						if (!empty($zoom_user_data)) {
							if (isset($zoom_user_data['id'])) {
								$zoom_user_id = $zoom_user_data['id'];
								$rData = $this->common_model->update($user_id, array('zoom_user_id' => $zoom_user_id), 'user_id', 'user_registration');
								// $members = array();
								// $members[] = array('id' => $zoom_user_id);
								// assign_role(1, $members);
							}
						}
					}
				}
			} 

			$active_conference = get_active_conference();
			if (!empty($active_conference)) {
				$meetings = $active_conference[0];
				$meeting_id = $meetings['vc_room_id'];
				$meeting_password = $meetings['vc_room_password'];
				$duration = $meetings['vc_duration'];
				$title = $meetings['vc_title'];
			}
			if ($meeting_id != '' && $duration > 0) {
				$host = 0;
				if ($user_role_id == 1) {
					$host = 1;
					$zak_token = generate_zoom_access_key($zoom_user_id);
				}
				$this->load->library('Jwt_lib');
				$client_id = $this->jwt_lib->zoom_sdk_client_id();
				$signature = $this->jwt_lib->generate_jwt($meeting_id, $host, $duration);
		   	//	echo $signature.'~'.$meeting_id;exit;
			}
		
//}
		$data['client_id'] = $client_id;
		$data['signature'] = $signature;
		$data['meeting_id'] = $meeting_id;
		$data['meeting_password'] = $meeting_password;
		$data['zak_token'] = $zak_token;
		$data['user_id'] = $user_id;
		$data['user_role_id'] = $user_role_id;
		$data['user_name'] = $user_name;
		$data['user_email'] = $user_email;
		$data['title'] = $title;
		$meeting_tile_data = $this->common_model->getRecordData('video_conference_title');
		$meeting_title = 'We do not currently have any active live sessions';
		if(!empty($meeting_tile_data)){
		    $meeting_title = $meeting_tile_data[0]['title1'];
		}
		$data['description'] = $description;
		$data['meeting_title'] = $meeting_title;
		$data['page_title'] = 'Video Conference';
		$this->load->view('admin/video_conference', $data);
	}

	function create_room()
	{

		$this->form_validation->set_rules('title', 'Title', 'trim|required|alpha_numeric_spaces|max_length[100]');
		//$this->form_validation->set_rules('description', 'Description', 'trim|alpha_numeric_spaces|max_length[250]');
		$this->form_validation->set_rules('duration', 'Duration', 'trim|required|integer');
		//$this->form_validation->set_rules('no_of_participant', 'No. Of Participant', 'trim|required|integer');

		if ($this->form_validation->run() == false) {
			$errors = validation_errors();
			$this->session->set_userdata('form-fail', $errors);
			redirect('admin/video_conference');
		} else {
			$title = $this->input->post('title');
			$duration = $this->input->post('duration');
			$user_id = get_user_id();
			$zoom_user_id = '';
			$user_data = $this->common_model->getRecordData('user_registration', "user_id = '$user_id'", 'zoom_user_id');
			if (!empty($user_data)) {
				$zoom_user_id = $user_data[0]['zoom_user_id'];
			}
			$meeting_data = create_zoom_meeting($title, $duration, $zoom_user_id);
			if (!empty($meeting_data)) {
				//$description = $this->input->post('description');
				//$no_of_participant = $this->input->post('no_of_participant');
				$room_id = $meeting_data['id'];
				$host_id = $meeting_data['host_email'];
				$password = $meeting_data['encrypted_password'];
				date_default_timezone_set('Asia/Kolkata');
				$start_time = date('Y-m-d H:i:s');
				$end_time = date('Y-m-d H:i:s', strtotime('+' . $duration . ' minute'));

				$data = array(
					'vc_host_id' => $host_id,
					'vc_room_id' => $room_id,
					'vc_room_password' => $password,
					'vc_title' => $title,
					'vc_duration' => $duration,
					'vc_start_time' => $start_time,
					'vc_end_time' => $end_time,
					'api_response' => json_encode($meeting_data),
				);
				$table = 'video_conference';
				$result = $this->common_model->insert($data, $table);
				if ((int)$result > 0) {
					$this->session->set_userdata('form-success', 'You Have Been Successfully Register With Bookk Worm');
				} else {
					$this->session->set_userdata('form-fail', 'Something Went Wrong! Please Try Again');
				}
			}
			sleep(2);
			redirect('admin/video_conference');
		}
	}

	function get_forex_symbol()
	{
		$api_url = forex_api_url() . 'list';
		$access_key = api_access_key();
		$data = array(
			'type' => urlencode('forex'),
			'access_key' => urlencode($access_key),
		);
		$retRec = curl_post($api_url, $data);
		$decodedJson = json_decode($retRec, true);
		$response = array();
		$info = array();
		if (count($decodedJson) > 0) {
			if (isset($decodedJson['status'])) {
				if ($decodedJson['status'] == 1) {
					if (isset($decodedJson['response'])) {
						$response = $decodedJson['response'];
					}
					if (isset($decodedJson['info'])) {
						$info = $decodedJson['info'];
					}
				}
			}
		}

		foreach ($response as $val) {
			$data = array(
				'symbol_id' => $val['id'],
				'symbol_name' => $val['name'],
				'symbol_decimal' => $val['decimal'],
				'symbol' => $val['symbol'],
				'update_time' => date('Y-m-d H:i:s'),
			);
			$table = 'forex_symbol';
			$result = $this->common_model->insert($data, $table);
		}

		echo 'Success';
	}

	public function manage_enquiry()
	{
		$data['page_title'] = 'Enquiry';
		if ($this->uri->segment(3) !== false) {
			$offset = $this->uri->segment(3);	//Set offset for paging
		} else {
			$offset = 0;	//Set offset for paging
		}

		$table = "contact_enquiry";
		$column = "contact_id";
		//Filter
		$contact_name = $this->session->userdata('contact_name');
		$phone_number = $this->session->userdata('phone_number');
		$contact_email = $this->session->userdata('contact_email');
		$enquiry_from = $this->session->userdata('contact_enquiry_from');
		$enquiry_to = $this->session->userdata('contact_enquiry_to');
		$enquiry_status = $this->session->userdata('enquiry_status');

		$limit = 10;	//Set totle number of records per page
		$config['base_url'] = site_url() . '/admin/manage_enquiry/';
		$config['total_rows'] = $this->common_model->get_totleforpaging($table, $column, $contact_name, $phone_number, $contact_email, $enquiry_from, $enquiry_to, $enquiry_status);	//Get totle number of rows for paging
		$config['per_page'] = $limit;
		$config["uri_segment"] = 3;

		$this->pagination->initialize($config);
		$data['result'] = $this->common_model->get_all_with_paging($limit, $offset, $table, $contact_name, $phone_number, $contact_email, $enquiry_from, $enquiry_to, $enquiry_status);		//Get all data from table
		$data['paging'] = $this->pagination->create_links();

		$this->load->view('admin/manage_enquiry', $data);
	}


	function filter_contact_enquiry()
	{
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {

			$contact_name = $this->input->post('contact_name');
			$phone_number = $this->input->post('phone_number');
			$contact_email = $this->input->post('contact_email');
			$contact_enquiry_from = $this->input->post('contact_enquiry_from');
			$contact_enquiry_to = $this->input->post('contact_enquiry_to');
			$enquiry_status = $this->input->post('enquiry_status');

			$this->session->unset_userdata('contact_name');
			$this->session->set_userdata('contact_name', $contact_name);

			$this->session->unset_userdata('phone_number');
			$this->session->set_userdata('phone_number', $phone_number);

			$this->session->unset_userdata('contact_email');
			$this->session->set_userdata('contact_email', $contact_email);

			$this->session->unset_userdata('contact_enquiry_from');
			$this->session->set_userdata('contact_enquiry_from', $contact_enquiry_from);

			$this->session->unset_userdata('contact_enquiry_to');
			$this->session->set_userdata('contact_enquiry_to', $contact_enquiry_to);

			$this->session->unset_userdata('enquiry_status');
			$this->session->set_userdata('enquiry_status', $enquiry_status);
		} else {
			$this->session->unset_userdata('contact_name');
			$this->session->unset_userdata('phone_number');
			$this->session->unset_userdata('contact_email');
			$this->session->unset_userdata('contact_enquiry_from');
			$this->session->unset_userdata('contact_enquiry_to');
			$this->session->unset_userdata('enquiry_status');
		}
		redirect('admin/manage_enquiry', 'refresh');
	}

	public function update_enquiry_status()
	{

		$id = (int)base64d($this->uri->segment(3));
		$value = $this->uri->segment(4);


		if ($value == 1) {
			$newvalue = 0;
		} else {
			$newvalue = 1;
		}

		$data = array('enquiry_status' => $newvalue);

		$result =  $this->common_model->update($id, $data, 'contact_id', 'contact_enquiry');

		if ($result) {
			$this->session->set_flashdata('message', $result);
			redirect('admin/manage_enquiry', 'refresh');
		}
	}
}//End Class
