<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Api extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->model('common_model');
	}
	
	function _access_key()
    {
        $AccessKey = 'VM3rzOcsspw2F4R0TWNlrubdPqY6v7WJ';
        return $AccessKey;
    }

    function _verify_login_key($login_key)
    {
        $result = '';
        if ($login_key != '') {
            
            $login_key = base64d($login_key);
            
            $explode_key = explode(':', $login_key);
            $user_id = '';
            $pwd = '';
            if (isset($explode_key[0])) {
                $user_id = $explode_key[0];
            }
            if (isset($explode_key[1])) {
                $pwd = $explode_key[1];
            }
            
            if ($user_id != '' && $pwd != '') {
                
                $cwhere =  "user_id = '$user_id' AND password = '$pwd'";
                $user_data = $this->common_model->getRecordData('user_registration',$cwhere);
                if(!empty($user_data)){
                    $result = $user_id;
                }
            }
            
        }
        return $result;
    }

    function get_signals_form_data(){
        $returnData = array();
        $returnData['status'] = 'error';
        $returnData['message'] = 'unauthorized method';
        $returnData['data'] = array();

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $access_key_posted = trim($this->input->post('auth_key'));
            $access_key = $this->_access_key();
            if ($access_key_posted == $access_key) {
                $login_key = trim($this->input->post('login_key'));
                $user_id = $this->_verify_login_key($login_key);
                if ($user_id != '') {
                    $all_period = $this->common_model->getRecordData('forex_period');
		            $all_symbol = $this->common_model->getRecordData('forex_symbol');

                    $returnData['status'] = 'success';
                    $returnData['message'] = '';
                    $returnData['data'] = array('all_period' => $all_period,'all_symbol'=>$all_symbol);
                } else {
                    $returnData['message'] = 'Invalid Request.';
                }
            } else {
                $returnData['message'] = 'unauthorized authentication';
            }
        }
        header('Content-Type: application/json');
        echo json_encode($returnData);
    }
    
    function get_symbol_analysis()
	{
		$returnData = array();
        $returnData['status'] = 'error';
        $returnData['message'] = 'unauthorized method';
        $returnData['data'] = array();

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $access_key_posted = trim($this->input->post('auth_key'));
            $access_key = $this->_access_key();
            if ($access_key_posted == $access_key) {
                $login_key = trim($this->input->post('login_key'));
                $user_id = $this->_verify_login_key($login_key);
                if ($user_id != '') {
                    $this->form_validation->set_rules('symbol', 'Symbol', 'trim|required');
                    $this->form_validation->set_rules('period', 'Time Period', 'trim|required');
                    if ($this->form_validation->run() == false) {
                        $errors = validation_errors();
                        $errors = str_replace("<p>", "", $errors);
                        $errors = str_replace("</p>", "", $errors);
                        $errors = str_replace("The", "", $errors);
                        $returnData['message'] = $errors;
                    } else {
                        $symbol = $this->input->post('symbol');
                        $period = $this->input->post('period');
                        $indicator_data = get_indecator_data($symbol, $period);
			            $pivot_point_data = get_pivot_point($symbol, $period);
                        $returnData['status'] = 'success';
                        $returnData['message'] = '';
                        $returnData['data'] = array('indicator_data' => $indicator_data,'pivot_point_data'=>$pivot_point_data);
                    }
                } else {
                    $returnData['message'] = 'Invalid Request.';
                }
            } else {
                $returnData['message'] = 'unauthorized authentication';
            }
        }
        header('Content-Type: application/json');
        echo json_encode($returnData);
	}
	
	function get_symbol_levels()
	{
		$returnData = array();
        $returnData['status'] = 'error';
        $returnData['message'] = 'unauthorized method';
        $returnData['data'] = array();

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $access_key_posted = trim($this->input->post('auth_key'));
            $access_key = $this->_access_key();
            if ($access_key_posted == $access_key) {
                $login_key = trim($this->input->post('login_key'));
                $user_id = $this->_verify_login_key($login_key);
                if ($user_id != '') {
                    $this->form_validation->set_rules('symbol', 'Symbol', 'trim|required');
                    $this->form_validation->set_rules('period', 'Time Period', 'trim|required');
                    if ($this->form_validation->run() == false) {
                        $errors = validation_errors();
                        $errors = str_replace("<p>", "", $errors);
                        $errors = str_replace("</p>", "", $errors);
                        $errors = str_replace("The", "", $errors);
                        $returnData['message'] = $errors;
                    } else {
                        $symbol = $this->input->post('symbol');
                        $period = $this->input->post('period');
			            $pivot_point_data = get_pivot_point($symbol, $period);
                        $returnData['status'] = 'success';
                        $returnData['message'] = '';
                        $returnData['data'] = array('pivot_point_data'=>$pivot_point_data);
                    }
                } else {
                    $returnData['message'] = 'Invalid Request.';
                }
            } else {
                $returnData['message'] = 'unauthorized authentication';
            }
        }
        header('Content-Type: application/json');
        echo json_encode($returnData);
	}
	
	function get_tutorials(){
	    $returnData = array();
        $returnData['status'] = 'error';
        $returnData['message'] = 'unauthorized method';
        $returnData['data'] = array();

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $access_key_posted = trim($this->input->post('auth_key'));
            $access_key = $this->_access_key();
            if ($access_key_posted == $access_key) {
                $login_key = trim($this->input->post('login_key'));
                $user_id = $this->_verify_login_key($login_key);
                if($user_id !=''){
                    $title1 = 'Introduction To Forex Part 1';
                    $video1 = base_url('resources/introduction_to_forex_part_1.mp4');
                    $title2 = 'Introduction To Forex Part 2';
                    $video2 = base_url('resources/introduction_to_forex_part_2.mp4');
                    $title3 = 'Introduction To Forex Part 3';
                    $video3 = base_url('resources/introduction_to_forex_part_3.mp4');
                    $title4 = 'Introduction To Forex Part 4';
                    $video4 = base_url('resources/introduction_to_forex_part_4.mp4');
                    $title5 = 'Introduction To Forex Part 5';
                    $video5 = base_url('resources/introduction_to_forex_part_5.mp4');
                    $videos_array = array(
                                        array(
                                            'title'=>$title1,
                                            'video'=>$video1
                                            ),
                                            array(
                                            'title'=>$title2,
                                            'video'=>$video2
                                            ),
                                            array(
                                            'title'=>$title3,
                                            'video'=>$video3
                                            ),
                                            array(
                                            'title'=>$title4,
                                            'video'=>$video4
                                            ),
                                            array(
                                            'title'=>$title5,
                                            'video'=>$video5
                                            )
                                    );
                    $returnData['status'] = 'success';
                    $returnData['message'] = '';
                    $returnData['data'] = array('tutorials'=>$videos_array);
                }else{
                    $returnData['message'] = 'Invalid login key.';
                }
            } else {
                $returnData['message'] = 'unauthorized authentication';
            }
        }
        header('Content-Type: application/json');
        echo json_encode($returnData);
	}
	
	function bookkworm_guide(){
	    $returnData = array();
        $returnData['status'] = 'error';
        $returnData['message'] = 'unauthorized method';
        $returnData['data'] = array();

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $access_key_posted = trim($this->input->post('auth_key'));
            $access_key = $this->_access_key();
            if ($access_key_posted == $access_key) {
                $login_key = trim($this->input->post('login_key'));
                $user_id = $this->_verify_login_key($login_key);
                if($user_id !=''){
                    $title1 = 'Bookkworm Guide';
                    $video1 = base_url('resources/bookkworm_explanation.mp4');
                    $videos_array = array(
                                        array(
                                            'title'=>$title1,
                                            'video'=>$video1
                                            )
                                    );
                    $returnData['status'] = 'success';
                    $returnData['message'] = '';
                    $returnData['data'] = array('guide'=>$videos_array);
                }else{
                    $returnData['message'] = 'Invalid login key.';
                }
            } else {
                $returnData['message'] = 'unauthorized authentication';
            }
        }
        header('Content-Type: application/json');
        echo json_encode($returnData);
	}

   
}

?>