<footer class="main-footer">
	<div class="pull-right d-none d-sm-inline-block">
		<ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
			<li class="nav-item">
				<a class="nav-link" href="javascript:void(0)">FAQ</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="#">Purchase Now</a>
			</li>
		</ul>
	</div>
	&copy; 2023 <a href="<?php echo site_url(); ?>">Bookk Worm</a>. All Rights Reserved.
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar">

	<div class="rpanel-title">
		<span class="pull-right btn btn-circle p-10">
			<img src="<?php echo base_url('images/svg-icon/close.svg'); ?>" data-toggle="control-sidebar" class="img-fluid svg-icon" alt="">
		</span>
	</div> <!-- Create the tabs -->
	<ul class="nav nav-tabs control-sidebar-tabs">
		<li class="nav-item"><a href="#control-sidebar-home-tab" data-bs-toggle="tab" class="active"><img src="<?php echo base_url('images/svg-icon/apps.svg'); ?>" class="img-fluid svg-icon" alt=""></a></li>
		<li class="nav-item"><a href="#control-sidebar-settings-tab" data-bs-toggle="tab"><img src="<?php echo base_url('images/svg-icon/advanced.svg'); ?>" class="img-fluid svg-icon" alt=""></a></li>
	</ul>
	<!-- Tab panes -->
	<div class="tab-content">
		<!-- Home tab content -->
		<div class="tab-pane active" id="control-sidebar-home-tab">
			<div class="flexbox">
				<a href="javascript:void(0)" class="text-grey">
					<i class="ti-more"></i>
				</a>
				<p>Users</p>
				<a href="javascript:void(0)" class="text-end text-grey"><i class="ti-plus"></i></a>
			</div>
			<div class="lookup lookup-sm lookup-right d-none d-lg-block">
				<input type="text" name="s" placeholder="Search" class="w-p100">
			</div>
			<div class="media-list media-list-hover mt-20">
				<div class="media py-10 px-0">
					<a class="avatar avatar-lg status-success" href="#">
						<img src="<?php echo base_url('images/avatar/1.jpg'); ?>" alt="...">
					</a>
					<div class="media-body">
						<p class="fs-16">
							<a class="hover-primary" href="#"><strong>Tyler</strong></a>
						</p>
						<p>Praesent tristique diam...</p>
						<span>Just now</span>
					</div>
				</div>

				<div class="media py-10 px-0">
					<a class="avatar avatar-lg status-danger" href="#">
						<img src="<?php echo base_url('images/avatar/2.jpg'); ?>" alt="...">
					</a>
					<div class="media-body">
						<p class="fs-16">
							<a class="hover-primary" href="#"><strong>Luke</strong></a>
						</p>
						<p>Cras tempor diam ...</p>
						<span>33 min ago</span>
					</div>
				</div>

				<div class="media py-10 px-0">
					<a class="avatar avatar-lg status-warning" href="#">
						<img src="<?php echo base_url('images/avatar/3.jpg'); ?>" alt="...">
					</a>
					<div class="media-body">
						<p class="fs-16">
							<a class="hover-primary" href="#"><strong>Evan</strong></a>
						</p>
						<p>In posuere tortor vel...</p>
						<span>42 min ago</span>
					</div>
				</div>

				<div class="media py-10 px-0">
					<a class="avatar avatar-lg status-primary" href="#">
						<img src="<?php echo base_url('images/avatar/4.jpg'); ?>" alt="...">
					</a>
					<div class="media-body">
						<p class="fs-16">
							<a class="hover-primary" href="#"><strong>Evan</strong></a>
						</p>
						<p>In posuere tortor vel...</p>
						<span>42 min ago</span>
					</div>
				</div>

				<div class="media py-10 px-0">
					<a class="avatar avatar-lg status-success" href="#">
						<img src="<?php echo base_url('images/avatar/1.jpg'); ?>" alt="...">
					</a>
					<div class="media-body">
						<p class="fs-16">
							<a class="hover-primary" href="#"><strong>Tyler</strong></a>
						</p>
						<p>Praesent tristique diam...</p>
						<span>Just now</span>
					</div>
				</div>

				<div class="media py-10 px-0">
					<a class="avatar avatar-lg status-danger" href="#">
						<img src="<?php echo base_url('images/avatar/2.jpg'); ?>" alt="...">
					</a>
					<div class="media-body">
						<p class="fs-16">
							<a class="hover-primary" href="#"><strong>Luke</strong></a>
						</p>
						<p>Cras tempor diam ...</p>
						<span>33 min ago</span>
					</div>
				</div>

				<div class="media py-10 px-0">
					<a class="avatar avatar-lg status-warning" href="#">
						<img src="<?php echo base_url('images/avatar/3.jpg'); ?>" alt="...">
					</a>
					<div class="media-body">
						<p class="fs-16">
							<a class="hover-primary" href="#"><strong>Evan</strong></a>
						</p>
						<p>In posuere tortor vel...</p>
						<span>42 min ago</span>
					</div>
				</div>

				<div class="media py-10 px-0">
					<a class="avatar avatar-lg status-primary" href="#">
						<img src="<?php echo base_url('images/avatar/4.jpg'); ?>" alt="...">
					</a>
					<div class="media-body">
						<p class="fs-16">
							<a class="hover-primary" href="#"><strong>Evan</strong></a>
						</p>
						<p>In posuere tortor vel...</p>
						<span>42 min ago</span>
					</div>
				</div>

			</div>

		</div>
		<!-- /.tab-pane -->
		<!-- Settings tab content -->
		<div class="tab-pane" id="control-sidebar-settings-tab">
			<div class="flexbox">
				<a href="javascript:void(0)" class="text-grey">
					<i class="ti-more"></i>
				</a>
				<p>Todo List</p>
				<a href="javascript:void(0)" class="text-end text-grey"><i class="ti-plus"></i></a>
			</div>
			<ul class="todo-list mt-20">
				<li class="py-15 px-5 by-1">
					<!-- checkbox -->
					<input type="checkbox" id="basic_checkbox_1" class="filled-in">
					<label for="basic_checkbox_1" class="mb-0 h-15"></label>
					<!-- todo text -->
					<span class="text-line">Nulla vitae purus</span>
					<!-- Emphasis label -->
					<small class="badge bg-danger"><i class="fa fa-clock-o"></i> 2 mins</small>
					<!-- General tools such as edit or delete-->
					<div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					</div>
				</li>
				<li class="py-15 px-5">
					<!-- checkbox -->
					<input type="checkbox" id="basic_checkbox_2" class="filled-in">
					<label for="basic_checkbox_2" class="mb-0 h-15"></label>
					<span class="text-line">Phasellus interdum</span>
					<small class="badge bg-info"><i class="fa fa-clock-o"></i> 4 hours</small>
					<div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					</div>
				</li>
				<li class="py-15 px-5 by-1">
					<!-- checkbox -->
					<input type="checkbox" id="basic_checkbox_3" class="filled-in">
					<label for="basic_checkbox_3" class="mb-0 h-15"></label>
					<span class="text-line">Quisque sodales</span>
					<small class="badge bg-warning"><i class="fa fa-clock-o"></i> 1 day</small>
					<div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					</div>
				</li>
				<li class="py-15 px-5">
					<!-- checkbox -->
					<input type="checkbox" id="basic_checkbox_4" class="filled-in">
					<label for="basic_checkbox_4" class="mb-0 h-15"></label>
					<span class="text-line">Proin nec mi porta</span>
					<small class="badge bg-success"><i class="fa fa-clock-o"></i> 3 days</small>
					<div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					</div>
				</li>
				<li class="py-15 px-5 by-1">
					<!-- checkbox -->
					<input type="checkbox" id="basic_checkbox_5" class="filled-in">
					<label for="basic_checkbox_5" class="mb-0 h-15"></label>
					<span class="text-line">Maecenas scelerisque</span>
					<small class="badge bg-primary"><i class="fa fa-clock-o"></i> 1 week</small>
					<div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					</div>
				</li>
				<li class="py-15 px-5">
					<!-- checkbox -->
					<input type="checkbox" id="basic_checkbox_6" class="filled-in">
					<label for="basic_checkbox_6" class="mb-0 h-15"></label>
					<span class="text-line">Vivamus nec orci</span>
					<small class="badge bg-info"><i class="fa fa-clock-o"></i> 1 month</small>
					<div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					</div>
				</li>
				<li class="py-15 px-5 by-1">
					<!-- checkbox -->
					<input type="checkbox" id="basic_checkbox_7" class="filled-in">
					<label for="basic_checkbox_7" class="mb-0 h-15"></label>
					<!-- todo text -->
					<span class="text-line">Nulla vitae purus</span>
					<!-- Emphasis label -->
					<small class="badge bg-danger"><i class="fa fa-clock-o"></i> 2 mins</small>
					<!-- General tools such as edit or delete-->
					<div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					</div>
				</li>
				<li class="py-15 px-5">
					<!-- checkbox -->
					<input type="checkbox" id="basic_checkbox_8" class="filled-in">
					<label for="basic_checkbox_8" class="mb-0 h-15"></label>
					<span class="text-line">Phasellus interdum</span>
					<small class="badge bg-info"><i class="fa fa-clock-o"></i> 4 hours</small>
					<div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					</div>
				</li>
				<li class="py-15 px-5 by-1">
					<!-- checkbox -->
					<input type="checkbox" id="basic_checkbox_9" class="filled-in">
					<label for="basic_checkbox_9" class="mb-0 h-15"></label>
					<span class="text-line">Quisque sodales</span>
					<small class="badge bg-warning"><i class="fa fa-clock-o"></i> 1 day</small>
					<div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					</div>
				</li>
				<li class="py-15 px-5">
					<!-- checkbox -->
					<input type="checkbox" id="basic_checkbox_10" class="filled-in">
					<label for="basic_checkbox_10" class="mb-0 h-15"></label>
					<span class="text-line">Proin nec mi porta</span>
					<small class="badge bg-success"><i class="fa fa-clock-o"></i> 3 days</small>
					<div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					</div>
				</li>
			</ul>
		</div>
		<!-- /.tab-pane -->
	</div>
</aside>
<!-- /.control-sidebar -->

<!-- Add the sidebar's background. This div must be placed immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->

<!-- ./side demo panel -->
<!-- <div class="sticky-toolbar">
	<a href="#" data-bs-toggle="tooltip" data-bs-placement="left" title="Buy Now" class="waves-effect waves-light btn btn-success btn-flat mb-5 btn-sm" target="_blank">
		<span class="icon-Money"><span class="path1"></span><span class="path2"></span></span>
	</a>
	<a href="https://themeforest.net/user/multipurposethemes/portfolio" data-bs-toggle="tooltip" data-bs-placement="left" title="Portfolio" class="waves-effect waves-light btn btn-danger btn-flat mb-5 btn-sm" target="_blank">
		<span class="icon-Image"></span>
	</a>
	<a id="chat-popup" href="#" data-bs-toggle="tooltip" data-bs-placement="left" title="Live Chat" class="waves-effect waves-light btn btn-warning btn-flat btn-sm">
		<span class="icon-Group-chat"><span class="path1"></span><span class="path2"></span></span>
	</a>
</div> -->
<!-- Sidebar -->

<div id="chat-box-body" style="display:none">
	<div id="chat-circle" class="waves-effect waves-circle btn btn-circle btn-lg btn-warning l-h-70">
		<div id="chat-overlay"></div>
		<span class="icon-Group-chat fs-30"><span class="path1"></span><span class="path2"></span></span>
	</div>

	<div class="chat-box">
		<div class="chat-box-header p-15 d-flex justify-content-between align-items-center">
			<div class="btn-group">
				<button class="waves-effect waves-circle btn btn-circle btn-primary-light h-40 w-40 rounded-circle l-h-45" type="button" data-bs-toggle="dropdown">
					<span class="icon-Add-user fs-22"><span class="path1"></span><span class="path2"></span></span>
				</button>
				<div class="dropdown-menu min-w-200">
					<a class="dropdown-item fs-16" href="#">
						<span class="icon-Color me-15"></span>
						New Group</a>
					<a class="dropdown-item fs-16" href="#">
						<span class="icon-Clipboard me-15"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></span>
						Contacts</a>
					<a class="dropdown-item fs-16" href="#">
						<span class="icon-Group me-15"><span class="path1"></span><span class="path2"></span></span>
						Groups</a>
					<a class="dropdown-item fs-16" href="#">
						<span class="icon-Active-call me-15"><span class="path1"></span><span class="path2"></span></span>
						Calls</a>
					<a class="dropdown-item fs-16" href="#">
						<span class="icon-Settings1 me-15"><span class="path1"></span><span class="path2"></span></span>
						Settings</a>
					<div class="dropdown-divider"></div>
					<a class="dropdown-item fs-16" href="#">
						<span class="icon-Question-circle me-15"><span class="path1"></span><span class="path2"></span></span>
						Help</a>
					<a class="dropdown-item fs-16" href="#">
						<span class="icon-Notifications me-15"><span class="path1"></span><span class="path2"></span></span>
						Privacy</a>
				</div>
			</div>
			<div class="text-center flex-grow-1">
				<div class="text-dark fs-18">Mayra Sibley</div>
				<div>
					<span class="badge badge-sm badge-dot badge-primary"></span>
					<span class="text-muted fs-12">Active</span>
				</div>
			</div>
			<div class="chat-box-toggle">
				<button id="chat-box-toggle" class="waves-effect waves-circle btn btn-circle btn-danger-light h-40 w-40 rounded-circle l-h-45" type="button">
					<span class="icon-Close fs-22"><span class="path1"></span><span class="path2"></span></span>
				</button>
			</div>
		</div>
		<div class="chat-box-body">
			<div class="chat-box-overlay">
			</div>
			<div class="chat-logs">
				<div class="chat-msg user">
					<div class="d-flex align-items-center">
						<span class="msg-avatar">
							<img src="<?php echo base_url('images/avatar/2.jpg'); ?>" class="avatar avatar-lg">
						</span>
						<div class="mx-10">
							<a href="#" class="text-dark hover-primary fw-bold">Mayra Sibley</a>
							<p class="text-muted fs-12 mb-0">2 Hours</p>
						</div>
					</div>
					<div class="cm-msg-text">
						Hi there, I'm Jesse and you?
					</div>
				</div>
				<div class="chat-msg self">
					<div class="d-flex align-items-center justify-content-end">
						<div class="mx-10">
							<a href="#" class="text-dark hover-primary fw-bold">You</a>
							<p class="text-muted fs-12 mb-0">3 minutes</p>
						</div>
						<span class="msg-avatar">
							<img src="<?php echo base_url('images/avatar/3.jpg'); ?>" class="avatar avatar-lg">
						</span>
					</div>
					<div class="cm-msg-text">
						My name is Anne Clarc.
					</div>
				</div>
				<div class="chat-msg user">
					<div class="d-flex align-items-center">
						<span class="msg-avatar">
							<img src="<?php echo base_url('images/avatar/2.jpg'); ?>" class="avatar avatar-lg">
						</span>
						<div class="mx-10">
							<a href="#" class="text-dark hover-primary fw-bold">Mayra Sibley</a>
							<p class="text-muted fs-12 mb-0">40 seconds</p>
						</div>
					</div>
					<div class="cm-msg-text">
						Nice to meet you Anne.<br>How can i help you?
					</div>
				</div>
			</div><!--chat-log -->
		</div>
		<div class="chat-input">
			<form>
				<input type="text" id="chat-input" placeholder="Send a message..." />
				<button type="submit" class="chat-submit" id="chat-submit">
					<span class="icon-Send fs-22"></span>
				</button>
			</form>
		</div>
	</div>
</div>

<!-- Page Content overlay -->


<!-- Vendor JS -->
<script src="<?php echo base_url('main/js/vendors.min.js'); ?>"></script>
<script src="<?php echo base_url('main/js/pages/chat-popup.js'); ?>"></script>
<script src="<?php echo base_url('assets/icons/feather-icons/feather.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor_components/jquery-toast-plugin-master/src/jquery.toast.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor_components/select2/dist/js/select2.full.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor_components/apexcharts-bundle/irregular-data-series.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor_components/apexcharts-bundle/dist/apexcharts.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor_components/jquery-steps-master/build/jquery.steps.js'); ?>"></script>
<script src="https://www.amcharts.com/lib/4/core.js"></script>
<script src="https://www.amcharts.com/lib/4/charts.js"></script>
<script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>
<script src="<?php echo base_url('assets/vendor_components/Web-Ticker-master/jquery.webticker.min.js'); ?>"></script>

<!-- Crypto Tokenizer Admin App -->
<script src="<?php echo base_url('main/js/template.js'); ?>"></script>
<script src="<?php echo base_url('main/js/pages/dashboard.js'); ?>"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
	jQuery.fn.bstooltip = jQuery.fn.tooltip;

	const Toast = Swal.mixin({
		toast: true,
		position: 'top-end',
		showConfirmButton: false,
		timer: 3000,
		timerProgressBar: true,
		onOpen: (toast) => {
			toast.addEventListener('mouseenter', Swal.stopTimer)
			toast.addEventListener('mouseleave', Swal.resumeTimer)
		}
	});
</script>
<?php $successMsg = $this->session->userdata('form-success');
$this->session->unset_userdata('form-success');
if ($successMsg != '') { ?>
	<script>
		$.toast({
			heading: '',
			text: '<?php echo $successMsg; ?>',
			position: 'top-right',
			loaderBg: '#ff6849',
			icon: 'success',
			hideAfter: 3500,
			stack: 6
		});
	</script>
<?php } else { ?>
	<?php $failMsg = $this->session->userdata('form-fail');
	$this->session->unset_userdata('form-fail');
	if ($failMsg != '') { ?>
		<script>
			$.toast({
				heading: '',
				text: '<?php echo $failMsg; ?>',
				position: 'top-right',
				loaderBg: '#ff6849',
				icon: 'error',
				hideAfter: 5500

			});
		</script>
	<?php } ?>
<?php } ?>
<script>
	$(document).ready(function() {
		$('.select2').select2();
	});

	$(document).on('submit', '.common-form-submit', function(e) {
		e.preventDefault();
		var form = $(this);
		$.post(form.attr("action"), form.serialize(), function(data) {
			if (Math.floor(data) == data && $.isNumeric(data)) {
				var redirectUrl = "<?php echo current_url(); ?>";
				window.location.href = redirectUrl;
			} else {
				if (data.includes("redirect#~@")) {
					var newData = data.replace("redirect#~@", "");
					window.location.href = $.trim(newData);
				} else {
					Swal.fire({
						icon: 'error',
						title: '',
						html: data,
					});
				}
			}
		});
	});
</script>
</body>

</html>