<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="<?php echo base_url('images/logo/logo-light-svg.svg'); ?>">

  <title>Bookk Worm</title>

  <!-- Vendors Style-->
  <link rel="stylesheet" href="<?php echo base_url('main/css/vendors_css.css'); ?>">

  <!-- Style-->
  <link rel="stylesheet" href="<?php echo base_url('main/css/style.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('main/css/skin_color.css'); ?>">

</head>

<body class="hold-transition light-skin sidebar-mini theme-warning fixed">

  <div class="wrapper">
    <div id="loader"></div>

    <header class="main-header">
      <div class="d-flex align-items-center logo-box justify-content-start">
        <a href="#" class="waves-effect waves-light nav-link rounded d-none d-md-inline-block push-btn" data-toggle="push-menu" role="button">
          <img src="<?php echo base_url('images/svg-icon/collapse.svg'); ?>" class="img-fluid svg-icon" alt="">
        </a>
        <!-- Logo -->
        <a href="<?php echo site_url(); ?>" class="logo">
          <div class="logo-lg">
            <span class="light-logo"><img src="<?php echo base_url('images/logo/BOOKWORMNEW.png'); ?>" alt="logo" style="width:60px;"></span>
            <span class="dark-logo"><img src="<?php echo base_url('images/logo/logo-light.jpeg'); ?>" alt="logo" style="width:60px;"></span>
          </div>
        </a>
      </div>
      <!-- Header Navbar -->
      <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
        <div class="app-menu">
          <ul class="header-megamenu nav">
            <li class="btn-group nav-item d-md-none">
              <a href="#" class="waves-effect waves-light nav-link push-btn btn-outline no-border" data-toggle="push-menu" role="button">
                <img src="<?php echo base_url('images/svg-icon/collapse.svg'); ?>" class="img-fluid svg-icon" alt="">
              </a>
            </li>
            <li class="btn-group nav-item">
              <a href="#" data-provide="fullscreen" class="waves-effect waves-light nav-link btn-outline no-border full-screen" title="Full Screen">
                <img src="<?php echo base_url('images/svg-icon/fullscreen.svg'); ?>" class="img-fluid svg-icon" alt="">
              </a>
            </li>
            <li class="btn-group d-lg-inline-flex d-none">
              <div class="app-menu">
                <div class="search-bx mx-5">
                  <form>
                    <div class="input-group">
                      <input type="search" class="form-control" placeholder="Search" aria-label="Search" aria-describedby="button-addon2">
                      <div class="input-group-append">
                        <button class="btn" type="submit" id="button-addon3"><img src="<?php echo base_url('images/svg-icon/search.svg'); ?>" class="img-fluid" alt="search"></button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </li>
          </ul>
        </div>

        <div class="navbar-custom-menu r-side">
          <ul class="nav navbar-nav">
            <!-- Notifications 
            <li class="dropdown notifications-menu">
              <a href="#" class="waves-effect waves-light dropdown-toggle btn-outline no-border" data-bs-toggle="dropdown" title="Notifications">
                <img src="<?php //echo base_url('images/svg-icon/notifications.svg'); ?>" class="img-fluid svg-icon" alt="">
              </a>
              <ul class="dropdown-menu animated bounceIn">

                <li class="header">
                  <div class="p-20">
                    <div class="flexbox">
                      <div>
                        <h4 class="mb-0 mt-0">Notifications</h4>
                      </div>
                      <div>
                        <a href="#" class="text-danger">Clear All</a>
                      </div>
                    </div>
                  </div>
                </li>

                <li>
                  <!-- inner menu: contains the actual data 
                  <ul class="menu sm-scrol">
                    <li>
                      <a href="#">
                        <i class="fa fa-users text-info"></i> Curabitur id eros quis nunc suscipit blandit.
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa fa-warning text-warning"></i> Duis malesuada justo eu sapien elementum, in semper diam posuere.
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa fa-users text-danger"></i> Donec at nisi sit amet tortor commodo porttitor pretium a erat.
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa fa-shopping-cart text-success"></i> In gravida mauris et nisi
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa fa-user text-danger"></i> Praesent eu lacus in libero dictum fermentum.
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa fa-user text-primary"></i> Nunc fringilla lorem
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="fa fa-user text-success"></i> Nullam euismod dolor ut quam interdum, at scelerisque ipsum imperdiet.
                      </a>
                    </li>
                  </ul>
                </li>
                <li class="footer">
                  <a href="#">View all</a>
                </li>
              </ul>
            </li>-->

            <!-- User Account-->
            <li class="dropdown user user-menu">
              <a href="#" class="waves-effect waves-light dropdown-toggle btn-outline no-border" data-bs-toggle="dropdown" title="User">
                <img src="<?php echo base_url('images/svg-icon/user.svg'); ?>" class="rounded svg-icon" alt="" />
              </a>
              <ul class="dropdown-menu animated flipInX">
                 <li class="user-body">
                <!--  <a class="dropdown-item" href="#"><i class="ti-user text-muted me-2"></i> Profile</a>
                  <a class="dropdown-item" href="#"><i class="ti-wallet text-muted me-2"></i> My Wallet</a>
                  <a class="dropdown-item" href="#"><i class="ti-settings text-muted me-2"></i> Settings</a>
                  <div class="dropdown-divider"></div>-->
                  <a class="dropdown-item" href="<?php echo site_url('user/logout'); ?>"><i class="ti-lock text-muted me-2"></i> Logout</a>
                </li>
              </ul>
            </li>
            <!-- Control Sidebar Toggle Button
            <li>
              <a href="#" data-toggle="control-sidebar" title="Setting" class="waves-effect waves-light btn-outline no-border">
                <img src="<?php //echo base_url('images/svg-icon/settings.svg'); ?>" class="img-fluid svg-icon" alt="">
              </a>
            </li> -->

          </ul>
        </div>
      </nav>
    </header>

    <aside class="main-sidebar">
      <!-- sidebar-->
      <section class="sidebar position-relative">
        <div class="multinav">
          <div class="multinav-scroll" style="height: 100%;">
            <!-- sidebar menu-->
            <ul class="sidebar-menu" data-widget="tree">
              <li class="treeview">
                <a href="#">
                  <img src="<?php echo base_url('images/svg-icon/sidebar-menu/dashboard.svg'); ?>" class="svg-icon" alt="">
                  <span>Dashboard</span>
                  <span class="pull-right-container">
                    <i class="fa fa-angle-right pull-right"></i>
                  </span>
                </a>
                <ul class="treeview-menu">
                  <li><a href="<?php echo site_url(); ?>"><i class="ti-more"></i>Dashboard</a></li>
                </ul>
              </li>
              <li>
                  <a href="<?php echo site_url('admin/heat_map'); ?>">
                    <img src="<?php echo base_url('images/svg-icon/sidebar-menu/color.svg'); ?>" class="svg-icon" alt="">
        			<span>Heat Map</span>
                  </a>
              </li>
              <li>
                  <a href="<?php echo site_url('admin/rates'); ?>">
                    <img src="<?php echo base_url('images/svg-icon/sidebar-menu/color.svg'); ?>" class="svg-icon" alt="">
        			<span>Cross Rates</span>
                  </a>
              </li>
              <li>
                  <a href="<?php echo site_url('admin/chart'); ?>">
                    <img src="<?php echo base_url('images/svg-icon/sidebar-menu/charts2.svg'); ?>" class="svg-icon" alt="">
        			<span>Symbols Chart</span>
                  </a>
              </li>
              <li>
                  <a href="<?php echo site_url('admin/rating'); ?>">
                    <img src="<?php echo base_url('images/svg-icon/sidebar-menu/reports.svg'); ?>" class="svg-icon" alt="">
        			<span>Bookkworm Signals</span>
                  </a>
              </li>
              <li>
                  <a href="<?php echo site_url('admin/levels'); ?>">
                    <img src="<?php echo base_url('images/svg-icon/sidebar-menu/reports.svg'); ?>" class="svg-icon" alt="">
        			<span>Currency Levels</span>
                  </a>
              </li>
              <li>
                  <a href="<?php echo site_url('admin/calculator'); ?>">
                    <img src="<?php echo base_url('images/svg-icon/sidebar-menu/reports.svg'); ?>" class="svg-icon" alt="">
        			<span>Lot Size Calculator</span>
                  </a>
              </li>
              <li>
                  <a href="<?php echo site_url('admin/news'); ?>">
                    <img src="<?php echo base_url('images/svg-icon/sidebar-menu/pages.svg'); ?>" class="svg-icon" alt="">
        			<span>Forex News</span>
                  </a>
              </li>
              <li>
                  <a href="<?php echo site_url('admin/converter'); ?>">
                    <img src="<?php echo base_url('images/svg-icon/sidebar-menu/transactions.svg'); ?>" class="svg-icon" alt="">
        			<span>Currency Converter</span>
                  </a>
              </li>
              <li>
                  <a href="<?php echo site_url('admin/calendar'); ?>">
                    <img src="<?php echo base_url('images/svg-icon/sidebar-menu/color.svg'); ?>" class="svg-icon" alt="">
        			<span>Economic Calendar</span>
                  </a>
              </li>
              <li>
                  <a href="<?php echo site_url('admin/tutorial'); ?>">
                    <img src="<?php echo base_url('images/svg-icon/video-camera.svg'); ?>" class="svg-icon" alt="">
        			<span>Tutorials</span>
                  </a>
              </li>
              <li>
                  <a href="<?php echo site_url('admin/guide'); ?>">
                    <img src="<?php echo base_url('images/svg-icon/video-camera.svg'); ?>" class="svg-icon" alt="">
        			<span>Bookkworm Guide</span>
                  </a>
              </li>
               <li>
                  <a href="<?php echo site_url('admin/video_conference'); ?>">
                    <img src="<?php echo base_url('images/svg-icon/video-camera.svg'); ?>" class="svg-icon" alt="">
        			<span>Live Conference</span>
                  </a>
              </li>
            </ul>
          </div>
        </div>
      </section>
    </aside>