<?php $this->load->view('admin/common/header'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <div class="container-full">
        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-lg-6 col-12">
                    <div class="box">
                        <div class="box-header with-border bg-dark">
                            <h4 class="box-title">Introduction To Forex Part 1</h4>
                        </div>
                        <div class="box-body p-0">
                            <video controls style="width:100%;">
                              <source src="<?php echo base_url('resources/introduction_to_forex_part_1.mp4'); ?>" type="video/mp4">
                            </video>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <div class="box">
                        <div class="box-header with-border bg-dark">
                            <h4 class="box-title">Introduction To Forex Part 2</h4>
                        </div>
                        <div class="box-body p-0">
                            <video controls style="width:100%;">
                              <source src="<?php echo base_url('resources/introduction_to_forex_part_2.mp4'); ?>" type="video/mp4">
                            </video>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-12">
                    <div class="box">
                        <div class="box-header with-border bg-dark">
                            <h4 class="box-title">Introduction To Forex Part 3</h4>
                        </div>
                        <div class="box-body p-0">
                            <video controls style="width:100%;">
                              <source src="<?php echo base_url('resources/introduction_to_forex_part_3.mp4'); ?>" type="video/mp4">
                            </video>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <div class="box">
                        <div class="box-header with-border bg-dark">
                            <h4 class="box-title">Introduction To Forex Part 4</h4>
                        </div>
                        <div class="box-body p-0">
                            <video controls style="width:100%;">
                              <source src="<?php echo base_url('resources/introduction_to_forex_part_4.mp4'); ?>" type="video/mp4">
                            </video>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-12">
                    <div class="box">
                        <div class="box-header with-border bg-dark">
                            <h4 class="box-title">Introduction To Forex Part 5</h4>
                        </div>
                        <div class="box-body p-0">
                            <video controls style="width:100%;">
                              <source src="<?php echo base_url('resources/introduction_to_forex_part_5.mp4'); ?>" type="video/mp4">
                            </video>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- /.content -->
    </div>
</div>
<!-- /.content-wrapper -->

<?php $this->load->view('admin/common/footer'); ?>
