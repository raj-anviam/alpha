<?php $this->load->view('admin/common/header'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <div class="container-full">
        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-lg-6 col-12">
                    <div class="box">
                        <div class="box-header with-border bg-dark">
                            <h4 class="box-title">Bookkworm Guide</h4>
                        </div>
                        <div class="box-body p-0">
                            <video controls style="width:100%;">
                              <source src="<?php echo base_url('resources/bookkworm_explanation.mp4'); ?>" type="video/mp4">
                            </video>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- /.content -->
    </div>
</div>
<!-- /.content-wrapper -->

<?php $this->load->view('admin/common/footer'); ?>
