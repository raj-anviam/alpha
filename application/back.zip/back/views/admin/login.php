<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo base_url('images/logo/logo-light-svg.svg'); ?>">

    <title>Bookk Worm</title>

    <!-- Vendors Style-->
    <link rel="stylesheet" href="<?php echo base_url('main/css/vendors_css.css'); ?>">

    <!-- Style-->
    <link rel="stylesheet" href="<?php echo base_url('main/css/style.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('main/css/skin_color.css'); ?>">

</head>

<body class="hold-transition theme-primary bg-img" style="background-image: url(<?php echo base_url('images/auth-bg/login-bg.png'); ?>)">

    <div class="container h-p100">
        <div class="row align-items-center justify-content-md-center h-p100">

            <div class="col-12">
                <div class="row justify-content-center g-0">
                    <div class="col-lg-5 col-md-5 col-12">
                        <div class="bg-white rounded10 shadow-lg">
                            <div class="content-top-agile p-20 pb-0">
                                <h2 class="text-primary">Let's Get Started</h2>
                                <p class="mb-0">Sign in to continue to Book Worm.</p>
                            </div>
                            <div class="p-40">
                                <form action="<?php echo site_url('user/login'); ?>" method="post">
                                    <div class="form-group">
                                        <div class="input-group mb-3">
                                            <span class="input-group-text bg-transparent"><i class="ti-user"></i></span>
                                            <input type="text" name="email" value="<?php echo set_value('email'); ?>" class="form-control ps-15 bg-transparent" placeholder="Username" required>
                                        </div>
                                        <?php echo form_error('email', '<span class="error invalid-feedback" style="display:block">', '</span>') ?>
                                    </div>
                                    <div class="form-group">
                                        <div class="input-group mb-3">
                                            <span class="input-group-text  bg-transparent"><i class="ti-lock"></i></span>
                                            <input type="password" name="pwd" class="form-control ps-15 bg-transparent" placeholder="Password" required>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <!-- <div class="col-6">
                                            <div class="checkbox">
                                                <input type="checkbox" id="basic_checkbox_1">
                                                <label for="basic_checkbox_1">Remember Me</label>
                                            </div>
                                        </div> -->
                                        <!-- /.col -->
                                        <!-- <div class="col-6">
                                            <div class="fog-pwd text-end">
                                                <a href="javascript:void(0)" class="hover-warning"><i class="ion ion-locked"></i> Forgot pwd?</a><br>
                                            </div>
                                        </div> -->
                                        <!-- /.col -->
                                        <div class="col-12 text-center">
                                            <button type="submit" class="btn btn-danger mt-10">SIGN IN</button>
                                        </div>
                                        <!-- /.col -->
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Vendor JS -->
    <script src="<?php echo base_url('main/js/vendors.min.js'); ?>"></script>
    <script src="<?php echo base_url('main/js/pages/chat-popup.js'); ?>"></script>
    <script src="<?php echo base_url('assets/icons/feather-icons/feather.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendor_components/jquery-toast-plugin-master/src/jquery.toast.js'); ?>"></script>
    <?php $successMsg = $this->session->userdata('form-success');
    $this->session->unset_userdata('form-success');
    if ($successMsg != '') { ?>
        <script>
            $.toast({
                heading: '',
                text: '<?php echo $successMsg; ?>',
                position: 'top-right',
                loaderBg: '#ff6849',
                icon: 'success',
                hideAfter: 3500,
                stack: 6
            });
        </script>
    <?php } else { ?>
        <?php $failMsg = $this->session->userdata('form-fail');
        $this->session->unset_userdata('form-fail');
        if ($failMsg != '') { ?>
            <script>
                    $.toast({
                        heading: '',
                        text: '<?php echo $failMsg; ?>',
                        position: 'top-right',
                        loaderBg: '#ff6849',
                        icon: 'error',
                        hideAfter: 5500

                    });
            </script>
        <?php } ?>
    <?php } ?>
</body>

</html>