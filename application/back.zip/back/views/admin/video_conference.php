<?php if ($signature != '' && $meeting_id != '') { }else{$this->load->view('admin/common/header');} ?>
<style>
    /* To hide */
    #zmmtg-root {
        display:none;
        position: unset;
    }

    .mini-layout-body {
        margin: 0 !important;
        margin-top: 10px !important;
        margin-left: 24% !important;
    }

    .mini-layout-body-title {
        margin: 0 !important;
    }

    .meeting-app {
        width: 100% !important;
    }

    #wc-loading {
        width: 100% !important;
        height: 100% !important;
    }

    #content_container {
        width: 100% !important;
        height: 100% !important;
    }
</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <div class="container-full">
        <!-- Main content -->
        <section class="content">
            <?php if ($signature != '' && $meeting_id != '') { ?>
                <div class="row">
                    <div class="col-xl-12 col-12">
                        <div class="ReactModal__Body--open">
                            <!-- added on import -->
                            <div id="zmmtg-root"></div>
                            <div id="aria-notify-area"></div>

                            <!-- added on meeting init -->
                            <div class="ReactModalPortal"></div>
                            <div class="ReactModalPortal"></div>
                            <div class="ReactModalPortal"></div>
                            <div class="ReactModalPortal"></div>
                            <div class="global-pop-up-box"></div>
                            <div class="sharer-controlbar-container sharer-controlbar-container--hidden"></div>
                        </div>

                    </div>
                </div>
            <?php } else { ?>
                <?php if ($user_role_id == 1) { ?>
                    <div class="box">
                        <div class="box-body">

                            <form action="<?php echo site_url('admin/create_room'); ?>" method="post">
                                <div class="row">
                                    <div class="col-xl-6 col-3 form-group">
                                        <input type="text" name="title" value="<?php echo set_value('title'); ?>" class="form-control ps-15 bg-transparent" placeholder="Title" required>
                                        <?php echo form_error('title', '<span class="error invalid-feedback" style="display:block">', '</span>') ?>
                                    </div>
                                    <div class="col-xl-6 col-2 form-group">
                                        <input type="text" name="duration" value="<?php echo set_value('duration'); ?>" class="form-control ps-15 bg-transparent" placeholder="Duration In Minute" required>
                                        <?php echo form_error('duration', '<span class="error invalid-feedback" style="display:block">', '</span>') ?>
                                    </div>
                                    <div class="col-xl-6 col-2 form-group">
                                        <button type="submit" class="btn btn-danger mt-10">Start Meeting</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php } else { ?>
                    <div class="row">
                        <div class="col-xl-12 col-12">
                            <div class="alert alert-info"><?php echo $meeting_title; ?></div>
                        </div>
                    </div>
                <?php } ?>
            <?php  } ?>
        </section>
        <!-- /.content -->
    </div>
</div>
<!-- /.content-wrapper -->
<?php if ($signature != '' && $meeting_id != '') { ?>
    <!-- Dependencies for client view and component view -->
    <script src="https://source.zoom.us/3.8.5/lib/vendor/react.min.js"></script>
    <script src="https://source.zoom.us/3.8.5/lib/vendor/react-dom.min.js"></script>
    <script src="https://source.zoom.us/3.8.5/lib/vendor/redux.min.js"></script>
    <script src="https://source.zoom.us/3.8.5/lib/vendor/redux-thunk.min.js"></script>
    <script src="https://source.zoom.us/3.8.5/lib/vendor/lodash.min.js"></script>

    <!-- CDN for client view -->
    <script src="https://source.zoom.us/zoom-meeting-3.8.5.min.js"></script>
    <link type="text/css" rel="stylesheet" href="https://source.zoom.us/3.8.5/css/bootstrap.css" />
    <link type="text/css" rel="stylesheet" href="https://source.zoom.us/3.8.5/css/react-select.css" />

    <script>
    console.log(JSON.stringify(ZoomMtg.checkSystemRequirements()));

      // it's option if you want to change the WebSDK dependency link resources. setZoomJSLib must be run at first
       //ZoomMtg.setZoomJSLib("https://source.zoom.us/3.8.5/lib", "/av"); // CDN version defaul
       ZoomMtg.setZoomJSLib("https://source.zoom.us/3.8.5/lib", "/av"); // CDN version defaul
      // loads WebAssembly assets
        ZoomMtg.preLoadWasm()
        ZoomMtg.prepareWebSDK()
      
      //ZoomMtg.preLoadWasm();
      //ZoomMtg.prepareJssdk();
     const zoomMeetingSDK = document.getElementById('zmmtg-root');

        // To hide
        zoomMeetingSDK.style.display = 'none';

        // To show
        zoomMeetingSDK.style.display = 'block';
    ZoomMtg.init({
      leaveUrl: 'https://edu.bookkworm.com',
      //webEndpoint: meetingConfig.webEndpoint,
      //disableCORP: !window.crossOriginIsolated, // default true
      // disablePreview: false, // default false
      externalLinkPage: 'https://edu.bookkworm.com',
      success: function () {
       ZoomMtg.i18n.load('en-US');
        ZoomMtg.i18n.reload('en-US');
        ZoomMtg.join({
            sdkKey: '<?php echo $client_id; ?>',
            signature: '<?php echo $signature; ?>', // role in SDK signature needs to be 1
            meetingNumber: '<?php echo $meeting_id; ?>',
            passWord: '<?php echo $meeting_password; ?>',
            userName: '<?php echo $user_name; ?>',
            userEmail: '<?php echo $user_email; ?>',
          success: function (res) {
            console.log("join meeting success");
            console.log("get attendeelist");
            ZoomMtg.getAttendeeslist({});
            ZoomMtg.getCurrentUser({
              success: function (res) {
                console.log("success getCurrentUser", res.result.currentUser);
              },
            });
          },
          error: function (res) {
            console.log(res);
          },
        });
      },
      error: function (res) {
        console.log(res);
      },
    });

   
 
       
    </script>
<?php } ?>

<?php  if ($signature != '' && $meeting_id != '') { }else{ $this->load->view('admin/common/footer'); } ?>