<?php $this->load->view('admin/common/header'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <div class="container-full">
        <!-- Main content -->
        <section class="content">

            
            <div class="row">
                <div class="col-xl-12 col-12">
                    <div class="box">
                        <div class="box-header">
                            <h4 class="box-title">
                                Currency Converter
                            </h4>
                        </div>
                        <div class="box-body">
                            <!-- TradingView Widget BEGIN -->
                            <div class="tradingview-widget-container">
                                <div id="quotesWidgetConverter"></div>
                                    <script async type="text/javascript" data-type="quotes-widget" src="https://c.mql5.com/js/widgets/quotes/widget.js?v=1">
                                      {"type":"converter","filter":"EURUSD","datepicker":true,"details":true,"extras":["INR","USD","EUR","GBP","JPY","CHF","CNH","CAD","NOK","AUD","SGD","NZD","SEK","RUB"],"width":780,"height":340,"id":"quotesWidgetConverter"}
                                    </script>
                            </div>
                            <!-- TradingView Widget END -->
                        </div>
                    </div>
                </div>
            </div>
            
        </section>
        <!-- /.content -->
    </div>
</div>
<!-- /.content-wrapper -->

<?php $this->load->view('admin/common/footer'); ?>