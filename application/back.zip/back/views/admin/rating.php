<?php $this->load->view('admin/common/header'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <div class="container-full">
        <!-- Main content -->
        <section class="content">
            <div class="row">
                <?php foreach ($indicator_data as $symbol => $val) {
                    $summary = '';
                    if (isset($val['overall']['summary'])) {
                        $summary = $val['overall']['summary'];
                    }
                    $boxClass = 'badge-warning';
                    if (strpos(strtolower($summary), 'sell') !== false) {
                        $boxClass = 'badge-danger';
                    } elseif (strpos(strtolower($summary), 'buy') !== false) {
                        $boxClass = 'badge-success';
                    }

                ?>
                    <div class="col-lg-3 col-12">
                        <div class="box box-body pull-up">
                            <h3 class="no-margin text-bold text-center"><?php echo $symbol; ?></h3>
                            <div class="mt-10">
                                <p class="no-margin fw-600"><span class="badge <?php echo $boxClass; ?>" style="width:100%"><?php echo $summary; ?></span></p>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <?php /*?><div class="box">
                        <div class="box-header">
                            <h4 class="box-title">
                                Technical Rating
                            </h4>
                        </div>
                        <div class="box-body">
                            <!-- TradingView Widget BEGIN -->
                                <div class="tradingview-widget-container">
                                  <div class="tradingview-widget-container__widget"></div>
                                  <div class="tradingview-widget-copyright"><a href="#" rel="noopener" target="_blank"><span class="blue-text">Forex market</span></a> </div>
                                  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-screener.js" async>
                                  {
                                  "width": 940,
                                  "height": 523,
                                  "defaultColumn": "overview",
                                  "defaultScreen": "general",
                                  "market": "forex",
                                  "showToolbar": true,
                                  "colorTheme": "light",
                                  "locale": "in"
                                }
                                  </script>
                                </div>
                                <!-- TradingView Widget END -->
                        </div>
                    </div><?php */ ?>

            </div>
            <div class="row">
                <div class="col-lg-12 col-12">
                    <div class="box box-body">
                        <div class="row">
                            <div class="col-md-3 col-12">
                                <div class="form-group">
                                    <label class="form-label">Symbol</label>
                                    <select class="form-control select2" id="bw-forex-symbol">
                                        <option value="">Select</option>
                                        <?php foreach ($all_symbol as $val) { ?>
                                            <option value="<?php echo $val['symbol']; ?>"><?php echo $val['symbol']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <!-- /.form-group -->
                            </div>
                            <div class="col-md-3 col-12">
                                <div class="form-group">
                                    <label class="form-label">Time Frame</label>
                                    <select class="form-control select2" id="bw-forex-period">
                                        <option value="">Select</option>
                                        <?php foreach ($all_period as $val) { ?>
                                            <option value="<?php echo $val['period']; ?>"><?php echo $val['period_decscription']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <!-- /.form-group -->
                            </div>
                            <div class="col-md-3 col-12">
                                <div class="form-group">
                                    <label class="form-label">&nbsp;</label><br>
                                    <button type="button" class="waves-effect waves-light btn btn-sm btn-outline btn-rounded btn-success-light mb-5" id="bw-check-analysis">Get Analysis</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row" id="bw-analysis" style="display:none">
                <div class="col-lg-12 col-12">
                    <div class="box box-body" id="bw-summary">
                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <div class="box">
                        <div class="box-header with-border">
                            <h4 class="box-title"><strong>Analysis</strong></h4>
                        </div>
                        <div class="box-body" id="bw-analysis-detial" style="overflow-x:auto;">

                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <div class="box">
                        <div class="box-header with-border">
                            <h4 class="box-title"><strong>Levels</strong></h4>
                        </div>
                        <div class="box-body" id="bw-pivot-point" style="overflow-x:auto;">

                        </div>
                    </div>
                </div>

            </div>
        </section>
        <!-- /.content -->
    </div>
</div>
<!-- /.content-wrapper -->

<?php $this->load->view('admin/common/footer'); ?>
<script>
    $(document).on('click', '#bw-check-analysis', function() {
        $('.loader').show();
        var symbol = $('#bw-forex-symbol').val();
        var period = $('#bw-forex-period').val();
        $('#bw-analysis').hide();
        $('#bw-analysis-detial').html('');
        $('#bw-pivot-point').html('');
        $('#bw-summary').html('');
        if (symbol != '' && period != '') {
            var url = '<?php echo site_url('admin/get_symbol_analysis'); ?>';
            $.post(url, {
                symbol: symbol,
                period: period
            }, function(response) {
                $('.loader').hide();
                var result = $.parseJSON(response);
                if (result['status'] == 'success') {
                    $('#bw-analysis-detial').html(result['symbol_analysis']);
                    $('#bw-pivot-point').html(result['pivot_point']);
                    $('#bw-summary').html(result['summary']);
                    $('#bw-analysis').show();
                } else {
                    $.toast({
                        heading: '',
                        text: result['msg'],
                        position: 'top-right',
                        loaderBg: '#ff6849',
                        icon: 'error',
                        hideAfter: 3500

                    });
                }

            });
        } else {
            $('.loader').hide();
            $.toast({
                heading: '',
                text: 'Please select symbol and period.',
                position: 'top-right',
                loaderBg: '#ff6849',
                icon: 'info',
                hideAfter: 3000,
                stack: 6
            });
        }
    });
</script>