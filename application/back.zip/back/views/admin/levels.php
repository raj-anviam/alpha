<?php $this->load->view('admin/common/header'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <div class="container-full">
        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-lg-12 col-12">
                    <div class="box box-body">
                        <div class="row">
                            <div class="col-md-3 col-12">
                                <div class="form-group">
                                    <label class="form-label">Symbol</label>
                                    <select class="form-control select2" id="bw-forex-symbol">
                                        <option value="">Select</option>
                                        <?php foreach ($all_symbol as $val) { ?>
                                            <option value="<?php echo $val['symbol']; ?>"><?php echo $val['symbol']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <!-- /.form-group -->
                            </div>
                            <div class="col-md-3 col-12">
                                <div class="form-group">
                                    <label class="form-label">Time Frame</label>
                                    <select class="form-control select2" id="bw-forex-period">
                                        <option value="">Select</option>
                                        <?php foreach ($all_period as $val) { ?>
                                            <option value="<?php echo $val['period']; ?>"><?php echo $val['period_decscription']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <!-- /.form-group -->
                            </div>
                            <div class="col-md-3 col-12">
                                <div class="form-group">
                                    <label class="form-label">&nbsp;</label><br>
                                    <button type="button" class="waves-effect waves-light btn btn-sm btn-outline btn-rounded btn-success-light mb-5" id="bw-get-levels">Get Levels</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row" id="bw-analysis" style="display:none">
                <div class="col-lg-12 col-12">
                    <div class="box box-body" id="bw-summary">
                    </div>
                </div>
                <div class="col-lg-12 col-12">
                    <div class="box">
                        <div class="box-header with-border">
                            <h4 class="box-title"><strong>Analysis</strong></h4>
                        </div>
                        <div class="box-body" id="bw-pivot-point" style="overflow-x:auto;">

                        </div>
                    </div>
                </div>

            </div>
        </section>
        <!-- /.content -->
    </div>
</div>
<!-- /.content-wrapper -->
<?php $this->load->view('admin/common/footer'); ?>
<script>
    $(document).on('click', '#bw-get-levels', function() {
        $('.loader').show();
        var symbol = $('#bw-forex-symbol').val();
        var period = $('#bw-forex-period').val();
        $('#bw-analysis').hide();
        $('#bw-analysis-detial').html('');
        $('#bw-pivot-point').html('');
        $('#bw-summary').html('');
        if (symbol != '' && period != '') {
            var url = '<?php echo site_url('admin/get_levels_data'); ?>';
            $.post(url, {
                symbol: symbol,
                period: period
            }, function(response) {
                $('.loader').hide();
                var result = $.parseJSON(response);
                if (result['status'] == 'success') {
                    $('#bw-pivot-point').html(result['pivot_point']);
                    $('#bw-summary').html(result['summary']);
                    $('#bw-analysis').show();
                } else {
                    $.toast({
                        heading: '',
                        text: result['msg'],
                        position: 'top-right',
                        loaderBg: '#ff6849',
                        icon: 'error',
                        hideAfter: 3500

                    });
                }

            });
        } else {
            $('.loader').hide();
            $.toast({
                heading: '',
                text: 'Please select symbol and period.',
                position: 'top-right',
                loaderBg: '#ff6849',
                icon: 'info',
                hideAfter: 3000,
                stack: 6
            });
        }
    });
</script>