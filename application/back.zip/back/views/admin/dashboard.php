<?php $this->load->view('admin/common/header'); ?>
<!-- Content Wrapper. Contains page content -->

<div class="content-wrapper">
    <div class="container-full">
        <!-- Main content -->
        <section class="content">

            <div class="row">
                <div class="col-xl-12 col-12">
                    <div class="box">
                        <!-- TradingView Widget BEGIN -->
                        <div class="tradingview-widget-container">
                            <div class="tradingview-widget-container__widget"></div>
                            <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
                                {
                                    "symbols": [{
                                            "proName": "FX:USDCAD",
                                            "title": "USD/CAD"
                                        },
                                        {
                                            "proName": "FX_IDC:USDINR",
                                            "title": "USD/INR"
                                        },
                                        {
                                            "proName": "FX_IDC:EURUSD",
                                            "title": "EUR/USD"
                                        },
                                        {
                                            "proName": "BITSTAMP:BTCUSD",
                                            "title": "Bitcoin"
                                        },
                                        {
                                            "proName": "FX:USDJPY",
                                            "title": "USD/JPY"
                                        },
                                        {
                                            "proName": "FX:GBPUSD",
                                            "title": "GBP/USD"
                                        }
                                    ],
                                    "showSymbolLogo": true,
                                    "colorTheme": "light",
                                    "isTransparent": false,
                                    "displayMode": "adaptive",
                                    "locale": "in"
                                }
                            </script>
                        </div>
                        <!-- TradingView Widget END -->
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-8 col-12">
                    <div class="box">
                        <div class="box-header">
                            <h4 class="box-title">
                                Forex Market Heatmap
                            </h4>
                        </div>
                        <div class="box-body">
                            <!-- TradingView Widget BEGIN -->
                            <div class="tradingview-widget-container">
                                <div class="tradingview-widget-container__widget"></div>
                                <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-forex-heat-map.js" async>
                                    {
                                        "width": "100%",
                                        "height": "400",
                                        "currencies": [
                                            "EUR",
                                            "USD",
                                            "JPY",
                                            "GBP",
                                            "CHF",
                                            "AUD",
                                            "CAD",
                                            "NZD",
                                            "CNY"
                                        ],
                                        "isTransparent": false,
                                        "colorTheme": "light",
                                        "locale": "in"
                                    }
                                </script>
                            </div>
                            <!-- TradingView Widget END -->
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-12">
                    <div class="box">
                        <div class="box-header">
                            <h4 class="box-title">
                                Economic Calender
                            </h4>
                        </div>
                        <div class="box-body">
                        <div class="tradingview-widget-container">
                            <div id="economicCalendarWidget"></div>
                            <script async type="text/javascript" data-type="calendar-widget" src="https://www.tradays.com/c/js/widgets/calendar/widget.js?v=12">
                              {"width":"100%","height":"400","mode":"2"}
                            </script>
                        </div>
                        </div>
                        
                        
                        
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-xl-8 col-12">
                    <div class="box">
                        <div class="box-header">
                            <h4 class="box-title">
                                Forex Matrix
                            </h4>
                        </div>
                        <div class="box-body">
                            <div id="quotesWidgetMatrix"></div>
                            <script async type="text/javascript" data-type="quotes-widget" src="https://c.mql5.com/js/widgets/quotes/widget.js?v=1">
                              {"type":"matrix","filter":["EUR","USD","JPY","GBP","AUD","CAD","CHF","NZD","NOK"],"width":600,"height":420,"id":"quotesWidgetMatrix"}
                            </script>
                        </div>    
                    </div>
                </div>
                <div class="col-xl-4 col-12">
                    <div class="box">
                        <!-- TradingView Widget BEGIN -->
                        <div class="tradingview-widget-container">
                            
                        </div>
                        <!-- TradingView Widget END -->
                    </div>
                </div>
            </div>
        </section>
        <!-- /.content -->
    </div>
</div>
<!-- /.content-wrapper -->
<?php $this->load->view('admin/common/footer'); ?>
<script>
    $('.label-w6JJhLCp.bottom-w6JJhLCp').hide();
</script>