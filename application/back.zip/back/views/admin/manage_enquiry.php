<?php $this->load->view('admin/common/header'); ?>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Manage</h3>

                        <div class="card-tools">
                            <div class="input-group input-group-sm" style="width: 150px;">
                                <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-default">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0" style="height: 350px;">
                        <table class="table table-head-fix text-nowrap">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Subject</th>
                                    <th>Message</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                foreach ($result as $result) { ?>
                                    <tr>
                                        <td><?php echo $result['contact_name']; ?></td>
                                        <td><?php echo $result['contact_email']; ?></td>
                                        <td><?php echo $result['contact_mobile']; ?></td>
                                        <td><?php echo $result['contact_subject']; ?></td>
                                        <td><?php echo $result['contact_message']; ?></td>
                                        <td><?php echo date("M d, Y", strtotime($result['submission_date_time'])); ?></td>
                                        <td><?php if ($result['enquiry_status'] == 0) { ?>
                                                <a href="<?php echo site_url('admin/update_enquiry_status/' . base64e($result['contact_id']) . '/' . $result['enquiry_status']); ?>" class="btn btn-xs btn-outline-danger">Unattend</a>
                                                <?php } else { ?>Attend<?php } ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<!-- /.content -->
<?php $this->load->view('admin/common/footer'); ?>