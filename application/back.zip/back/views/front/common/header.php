<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title><?php echo $title; ?></title>

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css'); ?>" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/responsive.css'); ?>" />
  <link rel="icon" href="<?php echo base_url('assets/images/favicon.png'); ?>" type="images/svg" sizes="32x32">

  <!--  Fonts  -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/popper.min.js'); ?>"></script>
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
  <script>
    jQuery.fn.bstooltip = jQuery.fn.tooltip;

    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      onOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
      }
    });
  </script>
</head>

<body>

  <!--------------------header-------------->
  <header>
    <div class="container">
      <div class="row align-items-center justify-content-between">

        <div class="col logo-col">
          <div class="fxminer-logo">
            <a href="<?php echo site_url(); ?>"><img src="<?php echo base_url('assets/images/fxminer-logo.png'); ?>" alt=""></a>
            <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
              <img src="<?php echo base_url('assets/images/menu-bar.svg'); ?>" alt="">
            </button>
          </div>
        </div>
        <?php $uri1 = $this->uri->segment(1); ?>
        <div class="col">
          <div id="fxminer-nav" class="d-flex justify-content-md-end">
            <nav class="navbar navbar-expand-md navbar-light">
              <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                  <li class="nav-item <?php echo ($uri1 == '') ? 'active' : ''; ?>"><a class="nav-link" href="<?php echo site_url(); ?>">Home</a></li>
                  <li class="nav-item <?php echo ($uri1 == 'expert-advisors') ? 'active' : ''; ?>"><a class="nav-link" href="<?php echo site_url('expert-advisors'); ?>">Expert Advisors</a></li>
                  <li class="nav-item <?php echo ($uri1 == 'contact-us') ? 'active' : ''; ?>"><a class="nav-link" href="<?php echo site_url('contact-us'); ?>">Contact Us</a></li>
                </ul>
              </div>
            </nav>
          </div>
        </div>

      </div>
    </div>
  </header>
  <!----------------- /header-------------------->