<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-5 col-md-4">
				<div class="about-fxminer pr-lg-3">
					<h5>About FXMINER</h5>
					<p>Education opens up the mental and spiritual faculties of human being and aids in forming positive attitudes for the holistic and health growth of human society.</p>
				</div>
			</div>

			<div class="col-lg-3 col-md-3">
				<div class="footer-links">
					<h5>Quick Links</h5>
					<ul>
						<li><a href="<?php echo site_url(); ?>">> Home</a></li>
						<li><a href="<?php echo site_url('expert-advisors'); ?>">> Expert Advisors</a></li>
						<li><a href="<?php echo site_url('contact-us'); ?>">> Contact Us</a></li>
					</ul>
				</div>
			</div>

			<div class="col-lg-4 col-md-5">
				<div class="contact-us">
					<h5>Contact Us</h5>
					<address>
						<p><span><img src="<?php echo base_url('assets/images/home.svg'); ?>" alt="" / /></span> <span>126A Gandhi Nagar Jammu</span></p>
						<p><span><img src="<?php echo base_url('assets/images/phone.svg'); ?>" alt="" / /></span><span><a href="tel:0123456789">
									0123456789</a></span></p>
						<p><span><img src="<?php echo base_url('assets/images/envelope.svg'); ?>" alt="" / /></span><span><a href="mailto:info@fxminer.com">
									info@fxminer.com</a></span></p>

					</address>
				</div>
			</div>
		</div>
	</div>

	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-sm-6 text-sm-left">
					Coppyrights &copy; 2021 FXMINER . All rights reserved.
				</div>
				<div class="col-sm-6 text-sm-right">
					Powered by: Techfi developers
				</div>
			</div>
		</div>
	</div>
</footer>

<script>
	$(window).scroll(function() {
		if ($(this).scrollTop() > 5) {
			$('header').addClass("sticky");
		} else {
			$('header').removeClass("sticky");
		}
	});
</script>

<script type="text/javascript">
	window.addEventListener("load", function() {
		loadImage();
	});

	function loadImage() {
		$.ajax({
			url: "<?php echo site_url('front/captcha_code'); ?>",
			type: 'post',
			data: {
				action: 'load-image'
			},
			success: function(data) {
				var result = $.parseJSON(data);
				var image_name = result["success"];
				var folder = "<?php echo base_url('uploads/captcha/'); ?>";
				var x = document.getElementById("captcha_code");
				x.src = folder + image_name;
			}
		});
	}
</script>

<script type="text/javascript">
	$(document).on('submit', '#fxminer-enquiry-form', function(e) {
		e.preventDefault();
		var formData = $('#fxminer-enquiry-form').serialize();
		var url = $(this).attr('action');
		$.ajax({
			type: "POST",
			url: url,
			data: formData,
			success: function(data) {
				var result = $.parseJSON(data);
				if (result["success"] == true) {
					Swal.fire({
						icon: 'success',
						title: '',
						html: 'Enquiry has been submitted successfully',
					});
					$('#fxminer-enquiry-form')[0].reset();
					loadImage();
				} else {
					Swal.fire({
						icon: 'error',
						title: '',
						html: result['error'],
					});
				}
			}
		});
		return false;
	});
</script>
</body>

</html>