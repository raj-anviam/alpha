<?php $this->load->view('front/common/header'); ?>
<section>
	<div class="gbs-video-home position-relative">
		<div class="video-home position-relative">
			<img src="<?php echo base_url('assets/images/hero-image.jpg'); ?>" alt="" />
		</div>
		<div class="banner-content text-center">
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-12">
						<div class="banner-caption">
							<h1>Creating lucrative Futures <br>With Smart Investing</h1>
							<div class="action-btn mt-md-4 mt-2">
								<a class="default-btn smooth text-uppercase rounded-pill" href="<?php echo site_url('contact-us'); ?>">contact us</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section>
	<div class="consists-stages section-space">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="heading text-center">
						<h2>Our Consists Stages</h2>
						<p>The EA main task is to simplify trading and get profit. It is based on an algorithm that consists of three stages:</p>
					</div>
				</div>
			</div>

			<div class="consists-stages-view mt-xl-5 mt-lg-4 mt-3">
				<div class="row">
					<div class="col-md-4 text-center">
						<div class="service">
							<div class="icon smooth rounded-circle m-auto">
								<span class="rounded-circle smooth">
									<img src="<?php echo base_url('assets/images/market-analysis.svg'); ?>" alt="">
								</span>
							</div>
							<div class="service-title text-capitalize mt-md-3 mb-md-3">
								<h5>Market Analysis</h5>
							</div>
							<div class="service-description d-inline-block w-100 position-relative">
								<p>Our expert advisor analysis the market situation and looks for ways to enter the market investment.</p>
							</div>
						</div>
					</div>
					<!-- @end service -->

					<div class="col-md-4 text-center">
						<div class="service">
							<div class="icon smooth rounded-circle m-auto">
								<span class="rounded-circle smooth">
									<img src="<?php echo base_url('assets/images/order-indicators.svg'); ?>" alt="">
								</span>
							</div>
							<div class="service-title text-capitalize mt-md-3 mb-md-3">
								<h5>Orders Opening</h5>
							</div>
							<div class="service-description d-inline-block w-100 position-relative">
								<p>Two or three indicators send <br>signals and our expert advisor <br>opens a position</p>
							</div>
						</div>
					</div>
					<!-- @end service -->

					<div class="col-md-4 text-center">
						<div class="service">
							<div class="icon smooth rounded-circle m-auto">
								<span class="rounded-circle smooth">
									<img src="<?php echo base_url('assets/images/closing-orders.svg'); ?>" alt="">
								</span>
							</div>
							<div class="service-title text-capitalize mt-md-3 mb-md-3">
								<h5>Orders Closing</h5>
							</div>
							<div class="service-description d-inline-block w-100 position-relative">
								<p> Stop Loss and Take Profit orders are activated, or a signal of a trend reversal is sent, &amp; the advisor closes the position</p>
							</div>
						</div>
					</div>
					<!-- @end service -->

				</div>

			</div>
		</div>
	</div>
</section>


<section>
	<div class="stop-loss-take-profit section-space">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="heading text-center">
						<h2>Stop Loss &amp; Take Profit </h2>
					</div>
				</div>
			</div>

			<div class="stop-profit-loss">

				<div class="row align-items-center">
					<div class="col-md-7">
						<div class="service mt-0">
							<div class="service-title text-capitalize mt-md-3 mb-md-3">
								<h3>Stop Loss</h3>
							</div>
							<div class="service-description d-inline-block w-100 position-relative">
								<p>Stop Loss is a pending order, which a trader uses in order to limit losses. The trader sets Stop Loss in advance at the level, where the order should be closed if the price goes in wrong direction. The order is executed automatically.</p>
							</div>
						</div>
					</div>
					<!-- @end service -->

					<div class="col-md-5">
						<div class="profit-loss-image text-md-right pl-xl-5 pl-md-4">
							<img src="<?php echo base_url('assets/images/stop-loss.png'); ?>" alt="">
						</div>
					</div>
				</div>


				<div class="row align-items-center mt-md-5 mt-4 profit-row">

					<div class="col-md-5">
						<div class="profit-loss-image pl-xl-5 pl-md-4">
							<img src="<?php echo base_url('assets/images/take-profit.png'); ?>" alt="">
						</div>
					</div>

					<div class="col-md-7">
						<div class="service mt-0">
							<div class="service-title text-capitalize mt-md-3 mb-md-3">
								<h3>Take Profit</h3>
							</div>
							<div class="service-description d-inline-block w-100 position-relative">
								<p>Take Profit is a pending order that a trader uses to fix profits of a trade. The trader sets Take Profit in advance at the level where the transaction will be in profit. The order is also executed automatically.</p>
							</div>
						</div>
					</div>
					<!-- @end service -->
				</div>
			</div>
		</div>
	</div>
</section>

<section>
	<div class="fxminer-gain">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="gain-text">
						<h1>Our Gains: 5% - 20% Monthly</h1>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section>
	<div class="fxminer-version section-space">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="heading text-center">
						<h2>FxMiner Version</h2>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-12">
					<div class="version-infographic mt-xl-5 mt-lg-4 mt-3">
						<img src="<?php echo base_url('assets/images/fxminer-versions.svg'); ?>" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php $this->load->view('front/common/footer'); ?>