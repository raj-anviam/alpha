<?php $this->load->view('front/common/header'); ?>
<section>
	<div class="internal-page header-space position-relative">
		<div class="page-heading">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<h3>Strength Of Expert Advisors</h3>
					</div>
				</div>
			</div>
		</div>
		<div class="inner-banner">
			<img src="<?php echo base_url('assets/images/expert-advisor.jpg'); ?>" alt="">
		</div>
	</div>
</section>

<div class="strengths section-space">
	<div class="container">

		<div class="row align-items-center">
			<div class="col-lg-7">
				<div class="about-text right-space">
					<div class="heading">
						<h2>Emotions control</h2>
					</div>
					<p>Modern technologies perform tasks faster than a human: a calculator will compute how much will be 356*28 in a fraction of a second, while a sixth-grader will do calculations in columnar form for several minutes or even longer. So advisors are the same. Forex robots react immediately to the market situation, since it is factored in their program. The trader can be slow while deciding to open the order or not. Advisors enter the market perfectly, in the same second as soon as the necessary signal arrives.</p>
				</div>
			</div>

			<div class="col-lg-5">
				<div class="about-image">
					<img src="<?php echo base_url('assets/images/emotion-control.jpg'); ?>" alt="">
				</div>
			</div>
		</div>
		<!-- @end row -->

		<div class="row market-monitoring align-items-center mt-5 mb-5">
			<div class="col-lg-5">
				<div class="about-image">
					<img src="<?php echo base_url('assets/images/robot-market-monitoring.jpg'); ?>" alt="">
				</div>
			</div>

			<div class="col-lg-7">
				<div class="about-text left-space">
					<div class="heading">
						<h2>Round-the-clock market monitoring</h2>
					</div>
					<p>Robots monitor the market 24 hours a day. Many traders are not traders by vocation: they can be managers, carpenters, firefighters, etc. They can hardly combine a busy work schedule with a Forex trading. Then trading robots will help with that, as they do not sleep and get tired. They save time and bring profit.</p>
				</div>
			</div>

		</div>
		<!-- @end row -->

		<div class="row align-items-center">
			<div class="col-lg-7">
				<div class="about-text right-space">
					<div class="heading">
						<h2>Fast response</h2>
					</div>
					<p>Robots work following the given algorithm, they do not know fear, greed, anger. Unlike the trader EA won’t be afraid and close the transaction, it won’t go off at half-cock. And if it earns a profit, it won’t go back on the market for more prey. The emotional component is being deleted.</p>
				</div>
			</div>

			<div class="col-lg-5">
				<div class="about-image">
					<img src="<?php echo base_url('assets/images/quick-response.jpg'); ?>" alt="">
				</div>
			</div>
		</div>
		<!-- @end row -->
	</div>
</div>


<?php $this->load->view('front/common/footer'); ?>