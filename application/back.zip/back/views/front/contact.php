<?php $this->load->view('front/common/header'); ?>

<section>
	<div class="internal-page header-space position-relative">
		<div class="page-heading">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<h3>Contact Us</h3>
					</div>
				</div>
			</div>
		</div>
		<div class="inner-banner">
			<img src="<?php echo base_url('assets/images/contact-us.jpg'); ?>" alt="">
		</div>
	</div>
</section>


<section>
	<div class="contact-form section-space">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="heading text-center">
						<h2>Send Us A Message</h2>
					</div>
				</div>
			</div>

			<div class="row mt-xl-5 mt-md-4 mt-4">
				<div class="col-lg-7 col-md-6 pr-xl-5 pr-lg-4">
					<form action="<?php echo site_url('front/submit_enquiry'); ?>" method="post" id="fxminer-enquiry-form">

						<div class="row">

							<div class="col-lg-6">
								<div class="form-group">
									<input type="text" name="name" value="" placeholder="Full name" class="form-control default-input" required>
								</div>
							</div>
							<!-- @end input -->

							<div class="col-lg-6">
								<div class="form-group">
									<input type="email" name="email" value="" placeholder="Email address" class="form-control default-input" required>
								</div>
							</div>
							<!-- @end input -->

							<div class="col-lg-6">
								<div class="form-group">
									<input type="phone" name="mobile" value="" placeholder="Phone number" class="form-control default-input" required>
								</div>
							</div>
							<!-- @end input -->

							<div class="col-lg-6">
								<div class="form-group">
									<input type="text" name="subject" value="" placeholder="Subject" class="form-control default-input">
								</div>
							</div>
							<!-- @end input -->

							<div class="col-lg-12">
								<div class="form-group">
									<textarea name="message" placeholder="Description" class="form-control default-input" rows="6"></textarea>
								</div>
							</div>
							<!-- @end input -->
							<div class="form-group col-lg-4">
								<input type="text" name="captcha" id="captcha" value="" class="form-control" placeholder="Captcha" maxlength="6">
							</div>
							<div class="form-group col-lg-4">
								<img id="captcha_code" width="150" height="35" style="border:0;" />
								<a href='javascript:;' onclick='loadImage();'><img src="<?php echo base_url('assets/images/icon-kf.gif'); ?>" /></a>
							</div>
							<div class="col-lg-4 text-right">
								<input type="submit" class="default-btn smooth border-0 text-uppercase rounded-pill" value="Submit">
							</div>
							<!-- @end input -->

						</div>
					</form>
				</div>
				<!-- @end left side -->

				<div class="col-lg-5 col-md-6">
					<div class="map-frame h-100">
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3357.442868333724!2d74.85545151518006!3d32.70085768099504!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391e84b0bb6122ed%3A0xc1b477c66c373fcc!2s126%2FA%2C%20Gandhi%20Nagar%2C%20Jammu%2C%20180004!5e0!3m2!1sen!2sin!4v1631809652904!5m2!1sen!2sin" allowfullscreen="" loading="lazy"></iframe>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php $this->load->view('front/common/footer'); ?>