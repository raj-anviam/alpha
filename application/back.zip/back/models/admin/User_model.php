<?php
class User_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function validate_login($usr, $pass)
    {
        
        $this->db->group_start();
         $this->db->where('ur.email', $usr);
         $this->db->or_where('ur.username', $usr);
         $this->db->or_where('ur.user_id', $usr);
        $this->db->group_end();
        $this->db->where('ur.password', $pass);
        $this->db->where('ur.user_status', 0);
        $this->db->where('ur.admin_status', 0);
        $this->db->select('ur.*,ls.expire_date,ut.user_token_id');
        $this->db->from('user_registration as ur');
        $this->db->join("lifejacket_subscription as ls","ls.user_id = ur.user_id AND ls.status = 'Active'","left");
        $this->db->join("user_token as ut","ut.user_id = ur.user_id","left");
        $this->db->order_by('ls.ts','DESC');
        $this->db->limit(1);
        $result = $this->db->get();
        return $result->result_array();
    }

    function check_valid_cookie($user_id, $user_email)
    {
        $this->db->where('user_id', $user_id);
        $this->db->where('email', $user_email);
        $this->db->where('user_status', 0);
        $this->db->where('admin_status', 0);
        $this->db->select('user_id');
        $this->db->limit(1);
        $result = $this->db->get('user_registration');
        return $result->result_array();
    }
}
